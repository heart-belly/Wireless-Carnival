

#include "hero.h"
#include "buy_equip_strategy.h"
#include "patrol_strategy.h"
#include "patrol_strategy2.h"
#include "attack_strategy.h"
#include "attack_strategy2.h"
#include "cast_skill_strategy.h"
#include <utility>
#include "escape_strategy.h"
#include "debug_strategy.h"
#include <opening_strategy.h>
#include "game_config.h"
#include "revive_strategy.h"

Hero::Hero(unique_ptr<HeroCharacter> heroCharacter) : character_(std::move(heroCharacter))
{
    // strategies_.push_back(make_unique<DebugStrategy>());
    strategies_.push_back(make_unique<OpeningStrategy>());
    strategies_.push_back(make_unique<ReviveStrategy>());
    strategies_.push_back(make_unique<AttackStrategy2>());
    strategies_.push_back(make_unique<EscapeStrategy>());
    strategies_.push_back(make_unique<CastSkillStrategy>());
    strategies_.push_back(make_unique<PatrolStrategy>());
    strategies_.push_back(make_unique<AttackStrategy>());
    strategies_.push_back(make_unique<BuyEquipStrategy>());
    strategies_.push_back(make_unique<PatrolStrategy2>());
}

bool Hero::CastSkill(Action& action)
{
    return character_->CastSkill(*this, action);
}

Pos Hero::GetPos() const
{
    return heroInfo_.pos;
}

int Hero::GetId() const
{
    return heroInfo_.heroId;
}

void Hero::SetHeroInfo(HeroInfo heroInfo)
{
    hpLastRound_ = heroInfo_.hp;
    heroInfo_ = std::move(heroInfo);
}

HeroKind Hero::GetHeroKind() const
{
    return GetHeroClass(GetHeroType());
}

HeroType Hero::GetHeroType() const
{
    return (HeroType)heroInfo_.heroType;
}

const HeroInfo& Hero::GetHeroInfo() const
{
    return heroInfo_;
}

void Hero::DecideNextAction(Action& action)
{
    for (auto& strategy : strategies_) {
        if (strategy->DecideNextAction(*this, action)) {
            return;
        }
    }
    PRINT_WARN("no strategy can exec, idle");
    action.InitIdle();
}

// 找到当前英雄可以攻击的，血量最少的敌人
bool Hero::FindTarget(EnemyType type, Pos& targetPos)
{
    GameContext ins = GameContext::Instance();

    int minHp = INT32_MAX;
    bool find = false;
    const Pos& myPos = GetPos();

    switch (type) {
        case ENEMY_HERO: {
            for (const auto& oppHero : ins.GetOppHeroInfo()) {
                if (oppHero.isDead) {
                    continue;
                }
                if (oppHero.status.phyDamageImmu != -1) {
                    PRINT_ERROR("物理免疫，不攻击该英雄");
                    continue;
                }
                if (character_->CanAttackHero(myPos, oppHero.pos)) {
                    PRINT_WARN("my hero(%s,%s) can attack opp hero(%s,%s,hp=%d)", character_->GetName().c_str(),
                               myPos.toString().c_str(), GetHeroName((HeroType)oppHero.heroType).c_str(),
                               oppHero.pos.toString().c_str(), oppHero.hp);
                    find = true;
                    if (oppHero.hp < minHp) {
                        targetPos = oppHero.pos;
                        minHp = oppHero.hp;
                    }
                }
            }
            return find;
        }
        case ENEMY_SOLDIER: {
            for (const auto& oppSoldier : ins.GetOppSoldiers()) {
                if (character_->CanAttackOther(myPos, oppSoldier.pos)) {
                    PRINT_WARN("my hero(%s,%s) can attack opp soldier(%s hp=%d)", character_->GetName().c_str(),
                               myPos.toString().c_str(), oppSoldier.pos.toString().c_str(), oppSoldier.hp);
                    find = true;
                    if (oppSoldier.hp < minHp) {
                        targetPos = oppSoldier.pos;
                        minHp = oppSoldier.hp;
                    }
                }
            }
            return find;
        }
        case ENEMY_BUILDING: {
            for (const auto& oneTower : ins.GetOppDefenseTower()) {
                if (!ins.IsMySoldierInRange(oneTower)) {
                    continue;
                }
                for (const auto& towerPos : oneTower.poses) {
                    if (character_->CanAttackOther(myPos, towerPos)) {
                        targetPos = towerPos;
                        return true;
                    }
                }
            }
            return false;
        }
        default:
            return false;
    }
}

bool Hero::MoveTo(Pos target, Pos& next) const
{
    if (!CanMove()) {
        return false;
    }
    vector<Pos> targetList;
    targetList.push_back(target);
    return MoveTo(targetList, next);
}

bool Hero::MoveTo(const vector<Pos>& targetList, Pos& next) const
{
    if (!CanMove()) {
        return false;
    }
    GameContext& context = GameContext::Instance();
    const Map& roundMap = context.GetRoundMap();
    FindPathResult ret = roundMap.GetNextPos(GetPos(), targetList, next);
    return ret == PATH_FOUND;
}

// 判断英雄是否可以释放技能的函数
bool Hero::CanCastSkill(const Pos& targetPos, SkillId skillId, Pos& skillReleasePos) const
{
    return IsInSkillRange(GetPos(), targetPos, skillId, skillReleasePos);
}

const Skill* Hero::GetRoundSkillInfo(SkillId skillId) const
{
    for (const Skill& curSkill : GetHeroInfo().skills) {
        if (curSkill.skillId == skillId) {
            return &curSkill;
        }
    }
    return nullptr;
}

bool Hero::CanAttack() const
{
    int cantAttackRound = heroInfo_.status.cantAttack;
    if (cantAttackRound != -1) {
        PRINT_WARN("hero %s cant attack, left %d round", GetName().c_str(), cantAttackRound);
    }
    return cantAttackRound <= 0;
}

string Hero::GetName() const
{
    return GetHeroName(GetHeroType());
}

bool Hero::CanMove() const
{
    int cantMoveRound = heroInfo_.status.cantMove;
    if (cantMoveRound != -1) {
        PRINT_WARN("hero %s cant move, left %d round", GetName().c_str(), cantMoveRound);
    }
    return cantMoveRound <= 0;
}

bool Hero::IsDead() const
{
    return heroInfo_.isDead;
}

bool Hero::IsUnderAttack() const
{
    PRINT_ERROR("%d %d", heroInfo_.hp, hpLastRound_);
    return heroInfo_.hp < hpLastRound_;
}

/*
 * 对后排是否有威胁
 */
bool Hero::IsInDangerForBack(Pos& dangerPos, int& dangerDistance) const
{
    GameContext ins = GameContext::Instance();

    if (GetHeroInfo().status.phyDamageImmu != -1) {
        PRINT_ERROR("当前物理免疫，天下无敌，不需要跑路");
        return false;
    }

    for (const auto& oppHero : ins.GetOppHeroInfo()) {
        if (oppHero.isDead) {
            continue;
        }

        dangerPos = oppHero.pos;

        if (GetHeroInfo().hp > oppHero.hp) {
            // 比对方血量高，也不跑
            continue;
        }
        int enemyDistance = GetPos().CalcDistance(oppHero.pos, CHEBYSHEV);
        if (GetHeroKind() == HERO_BACK && GetHeroClass(oppHero.heroType) == HERO_FRONT &&
            enemyDistance <= SAFE_DISTANCE_TO_FRONT) {
            PRINT_ERROR("当前是后排英雄，距离对方前排%s太近了 %d，有危险", oppHero.pos.toString().c_str(),
                        enemyDistance);
            dangerDistance = SAFE_DISTANCE_TO_FRONT;
            return true;
        }
    }
    return false;
}

/*
 * 判断一定范围内是否有威胁
 */
bool Hero::IsInDanger(int range, Pos& dangerPos, int& dangerDistance) const
{
    GameContext ins = GameContext::Instance();

    if (GetHeroInfo().status.phyDamageImmu != -1) {
        PRINT_ERROR("当前物理免疫，天下无敌，不需要跑路");
        return false;
    }

    for (const auto& oppHero : ins.GetOppAliveHeroInfo()) {
        dangerPos = oppHero.pos;

        if (GetHeroInfo().hp > oppHero.hp) {
            // 比对方血量高，也不跑
            continue;
        }
        int enemyDistance = GetPos().CalcDistance(oppHero.pos, CHEBYSHEV);
        if (GetHeroKind() == HERO_BACK && GetHeroClass(oppHero.heroType) == HERO_FRONT &&
            enemyDistance <= SAFE_DISTANCE_TO_FRONT) {
            PRINT_ERROR("当前是后排英雄，距离对方前排%s太近了 %d，有危险", oppHero.pos.toString().c_str(),
                        enemyDistance);
            dangerDistance = SAFE_DISTANCE_TO_FRONT;
            return true;
        }

        if (enemyDistance <= range) {
            PRINT_ERROR("血量过低，距离敌方太近，评估是否要跑路");
            Hero* teamMate = ins.GetTeammate(*this);
            if (teamMate == nullptr) {
                PRINT_ERROR("nullptr");
                return false;
            }
            if (teamMate->IsDead()) {
                PRINT_ERROR("队友挂了，需要跑路");
                dangerDistance = range;
                return true;
            }
            int distance = GetPos().CalcDistance(teamMate->GetPos(), CHEBYSHEV);
            if (distance >= range) {
                PRINT_ERROR("和队友距离过远，需要跑路");
                dangerDistance = range;
                return true;
            }
        }
    }
    return false;
}

const unique_ptr<HeroCharacter>& Hero::GetCharacter() const
{
    return character_;
}

HeroCfg* Hero::GetHeroCfg()
{
    return character_->GetHeroConfig();
}

string Hero::ToString()
{
    return heroInfo_.ToString();
}

vector<EquipType> Hero::GetBuyEquipList() const
{
    return character_->GetBuyEquipList();
}

int Hero::getUseRevive() const {
    return this->useRevive;
}
void Hero::setUserRevive() {
     ++ (this->useRevive);
}
