#pragma once

#include "json_type.h"

class TeamAi {
public:
    static void DecideTeamAction(vector<HeroAction> &teamAction);
};