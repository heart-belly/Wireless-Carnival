#pragma once

#include "hero_character.h"
#include "hero_strategy.h"
#include <memory>

class HeroCharacter;
class HeroStrategy;

class Hero {
private:
    vector<unique_ptr<HeroStrategy> > strategies_;
    std::unique_ptr<HeroCharacter> character_;

public:
    const unique_ptr<HeroCharacter>& GetCharacter() const;
    Pos attackPos;
    bool haveAttackPos;

private:
    // 当前该英雄的信息，需要在require msg里面更新
    HeroInfo heroInfo_;
    int hpLastRound_ = 0;
    int useRevive = 0;

public:
    HeroType GetHeroType() const;
    const HeroInfo &GetHeroInfo() const;

public:
    explicit Hero(unique_ptr<HeroCharacter> heroCharacter);

    void SetHeroInfo(HeroInfo heroInfo);
    void DecideNextAction(Action& action);

    bool CastSkill(Action &action);
    Pos GetPos() const;
    int GetId() const;
    bool FindTarget(EnemyType type, Pos& targetPos);
    bool MoveTo(Pos target, Pos &next) const;
    bool MoveTo(const vector<Pos>& targetList, Pos &next) const;
    bool CanCastSkill(const Pos &targetPos, SkillId skillId, Pos &skillReleasePos) const;
    bool CanAttack() const;
    string GetName() const;
    bool CanMove() const;
    const Skill* GetRoundSkillInfo(SkillId skillId) const;
    bool IsDead() const;
    HeroKind GetHeroKind() const;
    bool IsUnderAttack() const;
    bool IsInDanger(int range, Pos& dangerPos, int& dangerDistance) const;
    bool IsInDangerForBack(Pos& dangerPos, int& dangerDistance) const;
    HeroCfg* GetHeroCfg();
    string ToString();
    vector<EquipType> GetBuyEquipList() const;
    int getUseRevive() const;
    void setUserRevive();
};