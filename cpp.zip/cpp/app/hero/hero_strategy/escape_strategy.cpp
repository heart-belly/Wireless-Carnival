#include "escape_strategy.h"

bool EscapeStrategy::DecideNextAction(Hero& hero, Action& nextAction)
{
    PRINT_INFO("enter");

    // 如果正在被防御塔攻击，则逃离攻击范围
    if (EscapeTowerAttack(hero, nextAction)) {
        return true;
    }
    return EscapeHeroAttack(hero, nextAction);
}

bool EscapeStrategy::EscapeHeroAttack(Hero& hero, Action& nextAction) const
{
    GameContext ins = GameContext::Instance();

    // 判断局势，如果确定打不过了，必须跑路
    int myHeroNum = 1;
    int myHeroHp = hero.GetHeroInfo().hp;
    for (auto skill : hero.GetHeroInfo().skills) {
        if (skill.cdRemainRound < 0) {
            myHeroHp += 100;
        }
    }
    int oppHeroNum = 0;
    int oppHeroHp = 0;
    const Pos& myPos = hero.GetPos();
    Hero* teammate = ins.GetTeammate(hero);
    bool find = false;  // 是否找到了可以集火攻击的英雄
    Pos targetHeroPos;
    int targetHeroHp = INT32_MAX;
    for (const auto& tmp : ins.GetOppAliveHeroInfo()) {
        if (myPos.CalcDistance(tmp.pos, CHEBYSHEV) <= 5) {
            find = true;
            if (tmp.hp < targetHeroHp) {
                targetHeroPos = tmp.pos;
                targetHeroHp = tmp.hp;
            }
            oppHeroNum++;
            oppHeroHp += tmp.hp;
            for (auto skill : tmp.skills) {
                if (skill.cdRemainRound < 0) {
                    oppHeroHp += 100;
                }
            }
            if (teammate != nullptr) {
                int distance = teammate->GetPos().CalcDistance(tmp.pos, CHEBYSHEV);
                if (distance <= 6) {
                    // 该敌方英雄可以被集火攻击
                    PRINT_WARN("找到了可以集火攻击的英雄%s", tmp.pos.toString().c_str());
                    if (myHeroNum < 2) {
                        myHeroHp += teammate->GetHeroInfo().hp;
                        myHeroNum++;
                        for (auto skill : teammate->GetHeroInfo().skills) {
                            if (skill.cdRemainRound < 0) {
                                myHeroHp += 100;
                            }
                        }
                    }
                }
            }
        }
    }





    hero.haveAttackPos = false;

    bool isInOppBuild = false;
    // 判断当前英雄有没有在对方塔里
    for (auto& build : ins.GetOppDefenseTower()) {
        for (int i = 0; i < 4; i ++ ) {
            if (build.poses[i].CalcDistance(myPos, MANHATTAN) <= 4) isInOppBuild = true;
        }
    }

    // 统计该英雄附近敌我双方的兵力数量
    int mySoldier = 0, oppSoldier = 0;
    for (auto& mys : ins.GetMySoldiers()) {
        if (myPos.CalcDistance(mys.pos, MANHATTAN) <= 3) mySoldier ++;
    }
    for (auto& opps : ins.GetOppSoldiers()) {
        if (myPos.CalcDistance(opps.pos, MANHATTAN) <= 1) oppSoldier ++;
    }

    if (find) {
        // 得到我英雄的具体血量
        int myHero1 = hero.GetHeroInfo().hp;
        int myHero2 = 0;
        if (teammate != nullptr) {
            myHero2 = teammate->GetHeroInfo().hp;
        }
        // 得到敌方英雄
        int sz = ins.GetOppAliveHeroInfo().size();
        int oppHeroR[2] = {0};
        for (int i = 0; i < sz; ++ i) {
            const auto& tmp = ins.GetOppAliveHeroInfo()[i];
             oppHeroR[i] = tmp.hp;
        }

        bool flag = (sz >= 2 && oppHeroR[0] >= 200 && oppHeroR[1] >= 200);

        if ((flag && myHeroHp < oppHeroHp) || isInOppBuild || (oppSoldier >= mySoldier * 2 && oppSoldier != 0)) {
            PRINT_ERROR("我方%d个英雄总血量%d低于对方%d个英雄总血量%d过多，必须跑!", myHeroNum, myHeroHp, oppHeroNum,
                        oppHeroHp);
            if (MoveToMyTower(hero.GetPos(), ins.GetRiskMap(), nextAction)) {
                return true;
            }
            PRINT_ERROR("无法绕过危险点");
            if (MoveToMyTower(hero.GetPos(), ins.GetRoundMap(), nextAction)) {
                return true;
            }
            PRINT_ERROR("无法找到回防御塔的路径");
        } else {
            PRINT_ERROR("我方%d个英雄总血量%d，对方%d个英雄总血量%d，可以打!", myHeroNum, myHeroHp, oppHeroNum,
                        oppHeroHp);
            hero.attackPos = targetHeroPos;
            hero.haveAttackPos = true;
            PRINT_ERROR("设置优先攻击英雄 %s %d", targetHeroPos.toString().c_str(), targetHeroHp);
        }
    }

    if (hero.GetHeroType() == SNIPER) {
        /*
         * 火枪的攻击距离是5，所以一直尽量保持距离对方英雄距离为5
         */
        for (const auto& oppHero : ins.GetOppAliveHeroInfo()) {
            // 如果火枪处于对手的普攻范围内，则尝试躲避
            if (myPos.IsNeighbor(oppHero.pos, 3, CHEBYSHEV) && hero.GetHeroInfo().hp < oppHero.hp &&
                oppHero.atkDis < 3) {
                PRINT_WARN("当前火枪距离敌方英雄近战%s过近，且血量%d小于对方%d，尝试走位",
                           oppHero.pos.toString().c_str(), hero.GetHeroInfo().hp, oppHero.hp);
                if (MoveToMyTower(hero.GetPos(), ins.GetRiskMap(), nextAction)) {
                    return true;
                }
                PRINT_ERROR("无法绕过危险点");
                if (MoveToMyTower(hero.GetPos(), ins.GetRoundMap(), nextAction)) {
                    return true;
                }
            }
        }
        return false;
    }
    return false;
}

bool EscapeStrategy::MoveToMyTower(const Pos& myPos, const Map& curMap, Action& nextAction)
{
    const GameContext& ins = GameContext::Instance();

    // 收集我方所有防御塔的位置
    vector<Pos> safePosList;
    for (auto tmp : ins.GetMyDefenseTower()) {
        safePosList.push_back(tmp.poses[0]);
    }
    Pos next;
    Pos target;
    int pathLength = 0;
    if (curMap.GetNextPos(myPos, safePosList, next, target, pathLength) == PATH_FOUND) {
        PRINT_WARN("向目标点%s移动，下一步的安全位置是%s，路径长度是%d", target.toString().c_str(),
                   next.toString().c_str(), pathLength);
        if (pathLength == 2) {
            PRINT_WARN("已经在目标点旁边，放弃移动");
            return false;
        } else {
            nextAction.InitMove(next);
            return true;
        }
    } else {
        PRINT_ERROR("找不到可以躲避的点，放弃");
        return false;
    }
}

bool EscapeStrategy::EscapeTowerAttack(Hero& hero, Action& action) const
{
    GameContext ins = GameContext::Instance();

    for (auto oppTower : ins.GetOppTowers()) {
        if (oppTower.hateId == hero.GetId()) {
            PRINT_ERROR("正在被防御塔攻击");
            return MoveToMyTower(hero.GetPos(), ins.GetRoundMap(), action);
        }
    }
    return false;
}
