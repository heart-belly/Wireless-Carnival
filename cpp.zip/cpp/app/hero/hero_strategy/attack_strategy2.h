#pragma once

#include "hero_strategy.h"

// 可以攻击的目标类型
struct AttackTarget2 {
    Pos pos;
    int distance;
    int hp = 0;
    EnemyType type = ENEMY_HERO;
};

class AttackStrategy2 : public HeroStrategy {
public:
    bool DecideNextAction(Hero& hero, Action& nextAction) override;
    vector<AttackTarget2> FindTarget(Hero& hero, Pos myPos, int distance);
};