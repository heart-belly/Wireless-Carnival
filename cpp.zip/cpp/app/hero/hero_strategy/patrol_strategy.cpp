#include "patrol_strategy.h"
#include "game_config.h"

bool PatrolStrategy::DecideNextAction(Hero& hero, Action& nextAction)
{
    PRINT_INFO("enter");
    GameContext ins = GameContext::Instance();
    Pos targetPos;
    Pos nextPos;
    Pos myPos = hero.GetPos();
    // 如果当前正在传送，则持续施法
    if (hero.GetHeroInfo().status.teleporting >= 0) {
        PRINT_WARN("正在传送");
        nextAction.InitIdle();
        return true;
    }

    // 如果我方防御塔下有敌方小兵，则移动或传送到我方防御塔
    for (const auto& myTower : ins.GetMyDefenseTower()) {
        if (ins.IsOppSoldierInRange(myTower) && ins.GetOppSoldierInRangeNumber(myTower) >= 2) {
            PRINT_WARN("我方防御塔下有敌人，向防御塔移动");

            // 如果距离远，有TP，则传送到防御塔
            int calcDistance = hero.GetPos().CalcDistance(myTower.poses[0], CHEBYSHEV);
            if (calcDistance >= 8) {
                for (auto& equip : hero.GetHeroInfo().equipments) {
                    if (equip.type == BOOTS_OF_TRAVEL && equip.cdRemain < 0) {
                        // 找到塔周围两格以内的空地
                        const vector<Pos>& neighbor = myTower.poses[0].GetNeighbor();
                        for (auto tmp : neighbor) {
                            if (ins.GetRoundMap().IsReachable(tmp)) {
                                nextAction.InitUseEquip(BOOTS_OF_TRAVEL, tmp);
                                PRINT_WARN("开始传送~");
                                return true;
                            }
                        }
                    }
                }
            }
        }
    }

    // 保存对应敌方小兵与距离的映射

    // 如果我方防御塔下有敌方英雄，则移动或传送到我方防御塔
    for (const auto& myTower : ins.GetMyDefenseTower()) {
        // 保存对应敌方小兵与距离的映射
        int canMoveDistance = 0;
        int opoSolids = ins.GetOppSoldierInRangeNumber(myTower);

        switch(opoSolids) {
            case 1 : canMoveDistance = 20;break;
            case 2 : canMoveDistance = 50;break;

            default : canMoveDistance = 100;
        }
        if (ins.IsOppHeroInRange(myTower) && ins.GetOppSoldierInRangeNumber(myTower) >= 1 && myPos.CalcDistance(myTower.poses[2], CHEBYSHEV) < canMoveDistance) {
            PRINT_WARN("我方防御塔下有敌方英雄，向防御塔移动");
            // 我方基地和防御塔统一为右上角
            if (hero.MoveTo(myTower.poses[3], nextPos) && !ins.IsMyHeroInRange(myTower)) {
                nextAction.InitMove(nextPos);
                return true;
            }
        }
    }

    // 如果距离另外一个英雄太远，且周围有敌方英雄，都优先靠拢
    Hero* teammate = ins.GetTeammate(hero);
    if (teammate == nullptr || teammate->IsDead()) {
        PRINT_WARN("队友已经挂了");
    } else {
        Pos danger;
        int dangerDistance;
        if (hero.IsInDanger(SAFE_DISTANCE_LOW_HP, danger, dangerDistance)) {
            PRINT_WARN("距离己方英雄过远，且周围有敌方高血量英雄，尝试靠拢");
            targetPos = teammate->GetPos();
            ins.GetRoundMap();
            if (hero.MoveTo(targetPos, nextPos)) {
                PRINT_INFO("靠拢");
                nextAction.InitMove(nextPos);
                return true;
            }
        }
    }

    // 如果是后排，且和前排距离很近，则跟着前排走
    if (hero.GetHeroKind() == HERO_BACK) {
        if (teammate == nullptr || teammate->IsDead()) {
            PRINT_ERROR("nullptr or dead");
        } else {
            targetPos = teammate->GetPos();
            if (hero.GetPos().CalcDistance(targetPos, CHEBYSHEV) <= DISTANCE_TEAMMATE) {
                if (hero.MoveTo(targetPos, nextPos)) {
                    PRINT_INFO("后排跟随前排移动");
                    nextAction.InitMove(nextPos);
                    return true;
                }
            }
        }
    }

    // 找到走的最远的小兵（就近原则）
    // 判断当前机器人的位置在下方还是上方

    int maxDistance = 0;
    // bool find = false;
    // int pos = -1; //  up : 0; down : 1;
    // if (hero.GetPos().y_ < ins.GetRoundMap().maxY / 2) pos = 1;
    // else {
    //     pos = 0;
    // }

    // for (const auto& mySoldier : ins.GetMySoldiers()) {
    //     if (pos == 0) {
    //         if (mySoldier.pos.y_ > ins.GetRoundMap().maxY / 2) {
    //             // 找到距离本方基地最远的小兵
    //             int tmp = abs(mySoldier.pos.x_ - ins.GetMyBase()->detail.poses[0].x_);
    //             if (tmp > maxDistance) {
    //                 find = true;
    //                 maxDistance = tmp;
    //                 targetPos = mySoldier.pos;
    //             }
    //         }
    //     } else if (pos == 1) {
    //         if (mySoldier.pos.y_ < ins.GetRoundMap().maxY / 2) {
    //             // 找到距离本方基地最远的小兵
    //             int tmp = abs(mySoldier.pos.x_ - ins.GetMyBase()->detail.poses[0].x_);
    //             if (tmp > maxDistance) {
    //                 find = true;
    //                 maxDistance = tmp;
    //                 targetPos = mySoldier.pos;
    //             }
    //         }            
    //     }
    // }

    // // 如果走过中线，或者已经和敌方小兵相遇，则跟随兵线
    // if (find) {
    //     bool needFollow = false;
    //     for (auto tmp : ins.GetOppSoldiers()) {
    //         if (targetPos.CalcDistance(tmp.pos, CHEBYSHEV) <= 5) {
    //             PRINT_WARN("上路兵线即将相遇");
    //             needFollow = true;
    //         }
    //     }

    //     if (needFollow || maxDistance > 12) {
    //         // 根据英雄的前后排类型，选择站位
    //         Pos offset;
    //         if (hero.GetHeroKind() == HERO_FRONT) {
    //             offset = Pos(0 * ins.GetDirection(), 1);
    //         } else {
    //             offset = Pos(-1 * ins.GetDirection(), 1);
    //         }
    //         targetPos = targetPos + offset;
    //         if (!hero.MoveTo(targetPos, nextPos)) {
    //             return false;
    //         }
    //         PRINT_INFO("跟随兵线移动，目标是%s", targetPos.toString().c_str());
    //         nextAction.InitMove(nextPos);
    //         return true;
    //     }
    // }

    // // 如果我方防御塔下有敌方小兵，则移动或传送到我方防御塔
    // for (const auto& myTower : ins.GetMyDefenseTower()) {
    //     if (ins.IsOppSoldierInRange(myTower)) {
    //         PRINT_WARN("我方防御塔下有敌人，向防御塔移动");
    //         // 我方基地和防御塔统一为右上角
    //         if (hero.MoveTo(myTower.poses[3], nextPos)) {
    //             nextAction.InitMove(nextPos);
    //             return true;
    //         }
    //     }
    // }

    // // 优先向离当前位置最近的防御塔移动
    // const vector<TowerDetail>& myTowers = ins.GetMyTowers();
    // if (myTowers.size() == 2) {
    //     // 记录防御塔距离当前英雄的距离
    //     int dist[2] = {0};
    //     for (int i = 0; i < myTowers.size(); ++ i ) {
    //         dist[i] = hero.GetPos().CalcDistance(myTowers[i].poses[3], CHEBYSHEV);
    //     }

    //     TowerDetail myTower = dist[0] < dist[1] ? myTowers[0] : myTowers[1];

    //     // 优先去最近的防御塔
    //     if (hero.GetPos().CalcDistance(myTower.poses[0], CHEBYSHEV) > 7) {
    //         for (auto& equip : hero.GetHeroInfo().equipments) {
    //             if (equip.type == BOOTS_OF_TRAVEL && equip.cdRemain < 0) {
    //                 // 找到塔周围两格以内的空地
    //                 const vector<Pos>& neighbor = myTower.poses[0].GetNeighbor();
    //                 for (auto tmp : neighbor) {
    //                     if (ins.GetRoundMap().IsReachable(tmp)) {
    //                         nextAction.InitUseEquip(BOOTS_OF_TRAVEL, tmp);
    //                         PRINT_WARN("开始传送~");
    //                         return true;
    //                     }
    //                 }
    //             }
    //         }
    //     }

    //     if (hero.MoveTo(myTower.poses[0], nextPos)) {
    //         nextAction.InitMove(nextPos);
    //         return true;
    //     }

    // }

    return false;
}