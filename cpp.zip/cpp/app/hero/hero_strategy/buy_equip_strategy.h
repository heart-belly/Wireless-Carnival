#pragma once

#include "hero_strategy.h"
#include "game_context.h"

class BuyEquipStrategy : public HeroStrategy {
public:
    bool DecideNextAction(Hero& hero, Action& nextAction) override;

private:
    bool BuyEquip(const Hero& hero, Action& nextAction) const;
    bool BuyRune(Hero& hero, Action& action);
    bool GoToPickRune(const Hero& hero, Action& action, Pos& runePos) const;
};