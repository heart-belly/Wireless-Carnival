#include "buy_equip_strategy.h"
#include "game_config.h"

bool BuyEquipStrategy::DecideNextAction(Hero& hero, Action& nextAction)
{
    GameContext gameContext = GameContext::Instance();

    // 计算当前英雄到商店和符文的距离
    int disToShop =  hero.GetPos().CalcDistance(gameContext.GetShop().poses[0], CHEBYSHEV), disToRune = hero.GetPos().CalcDistance(gameContext.GetRune().pos, CHEBYSHEV);

    if (disToShop < disToRune) {
        if (BuyEquip(hero, nextAction)) return true;
        if (BuyRune(hero, nextAction)) return true;
    } else {
        if (BuyRune(hero, nextAction)) return true;
        if (BuyEquip(hero, nextAction)) return true;
    }



    //  if (BuyEquip(hero, nextAction)) {
    //         return true;
    // }

    //  if (BuyRune(hero, nextAction)) {
    //     return true;
    // }
    return false;
}

bool BuyEquipStrategy::BuyEquip(const Hero& hero, Action& nextAction) const
{
    PRINT_INFO("enter");
    GameContext& ins = GameContext::Instance();
    const vector<Pos>& shopPosList = ins.GetShop().poses;
    Pos nextPos;
    const Pos& myPos = hero.GetPos();

    vector<EquipType> buyEquipIds = hero.GetBuyEquipList();

    if (hero.GetHeroInfo().money < 1500) {
        int calcDistance = myPos.CalcDistance(ins.GetShop().poses[0], CHEBYSHEV);
        if (calcDistance > 5 || hero.GetHeroInfo().money < 500) {
            return false;
        }
    }

//     if (myPos.CalcDistance(ins.GetShop().poses[0], CHEBYSHEV) > 5) {
//         PRINT_WARN("先向商店移动");
//         if (hero.MoveTo(ins.GetShop().poses, nextPos)) {
//             nextAction.InitMove(nextPos);
//             return true;
//         }
//     }

    unsigned long long int curEquipNum = hero.GetHeroInfo().equipments.size();
    if (curEquipNum >= 4) {
        PRINT_WARN("装备栏满了，不去买装备");
        return false;
    }

    for (auto onePos : shopPosList) {
        if (myPos == onePos) {
            // 已经到达商店位置，直接购买装备，从列表里面第一件装备开始买
            int totalMoney = hero.GetHeroInfo().money;
            vector<EquipType> toBuy;
            for (auto tmp : buyEquipIds) {
                int price = GetEquipPrice(tmp);
                if (totalMoney >= price) {
                    toBuy.push_back(tmp);
                    totalMoney -= price;
                    curEquipNum ++;
                    if (curEquipNum >= 4) {
                        break;
                    }
                }
            }
            while (totalMoney >= 200 && curEquipNum < 4) {
                toBuy.push_back(BOOTS_OF_TRAVEL);
                totalMoney -= 200;
                curEquipNum ++;
            }
            nextAction.InitBuyEquip(toBuy);
            return true;
        }
    }
    

    if (!hero.MoveTo(shopPosList, nextPos) || !isCanGo) {
        PRINT_ERROR("无法向商店位置移动");
        return false;
    }
    
    nextAction.InitMove(nextPos);
    return true;
}

bool BuyEquipStrategy::BuyRune(Hero& hero, Action& action)
{

    GameContext ins = GameContext::Instance();
    Rune rune = ins.GetRune();
    Pos runePos = rune.pos;
    if (hero.GetPos().CalcDistance(runePos, CHEBYSHEV)  > 5 || !rune.isValid) {
        return false;
    }

    PRINT_WARN("发现符文，去捡符文");
    return GoToPickRune(hero, action, runePos);
}

bool BuyEquipStrategy::GoToPickRune(const Hero& hero, Action& action, Pos& runePos) const
{
    if (hero.GetPos() != runePos) {
        Pos nextPos;
        if (hero.MoveTo(runePos, nextPos)) {
            PRINT_WARN("向符文位置移动");
            action.InitMove(nextPos);
            return true;
        } else {
            PRINT_ERROR("无法向符文位置移动");
            return false;
        }
    } else {
        PRINT_WARN("抢到了符文");
        return false;
    }
}