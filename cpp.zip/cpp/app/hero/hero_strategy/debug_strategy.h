#pragma once

#include "hero_strategy.h"

class DebugStrategy : public HeroStrategy {
public:
    bool DecideNextAction(Hero &hero, Action &nextAction) override;
    bool TestRifleman1(Hero& hero, Action& nextAction);
    bool TestRifleman2(Hero& hero, Action& nextAction);
    bool TestBuy(Hero& hero, Action& action);
    bool TestEscape(Hero& hero, Action& nextAction);
};