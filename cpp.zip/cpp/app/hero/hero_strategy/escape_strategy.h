#pragma once

#include "hero_strategy.h"
#include "game_context.h"

class EscapeStrategy : public HeroStrategy {
public:
    bool DecideNextAction(Hero& hero, Action& nextAction) override;
    bool EscapeHeroAttack(Hero& hero, Action& nextAction) const;
    bool EscapeTowerAttack(Hero& hero, Action& action) const;
    static bool MoveToMyTower(const Pos& myPos, const Map& curMap, Action& nextAction) ;
};