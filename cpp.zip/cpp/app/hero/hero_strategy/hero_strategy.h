#pragma once

#include "json_type.h"
#include "hero.h"

class HeroStrategy {
public:
    virtual ~HeroStrategy() = default;
    virtual bool DecideNextAction(Hero &hero, Action &nextAction) = 0;
};