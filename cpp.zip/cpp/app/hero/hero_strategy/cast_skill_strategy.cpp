#include "cast_skill_strategy.h"
#include "log.h"

bool CastSkillStrategy::DecideNextAction(Hero &hero, Action &nextAction)
{
    PRINT_INFO("enter");
    // 释放技能和当前英雄角色强相关，委托给英雄角色处理
    if (hero.GetHeroInfo().status.dizzy >= 0) {
        PRINT_WARN("处于眩晕状态，无法释放技能");
        return false;
    }
    return hero.CastSkill(nextAction);
}
