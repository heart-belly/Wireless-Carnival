#include <algorithm>
#include "attack_strategy.h"
#include "log.h"
#include "game_config.h"
#include "game_context.h"

static bool CompareTarget(const AttackTarget& a, const AttackTarget& b)
{
    // 先按照类型排序
    if (a.type != b.type) {
        return a.type < b.type;
    }
    // 再按照血量排序
    if (a.hp != b.hp) {
        return a.hp < b.hp;
    }
    // 按照距离排序
    return a.distance < b.distance;
}

bool AttackStrategy::DecideNextAction(Hero& hero, Action& nextAction)
{
    PRINT_INFO("enter");
    Pos targetPos;

    if (!hero.CanAttack()) {
        return false;
    }

    if (hero.haveAttackPos) {
        PRINT_WARN("有建议攻击的目标");
        if (hero.GetCharacter()->CanAttackHero(hero.GetPos(), hero.attackPos)) {
            PRINT_WARN("普通攻击%s", hero.attackPos.toString().c_str());
            nextAction.InitAttack(hero.attackPos);
            return true;
        } else {
            PRINT_WARN("向建议攻击目标移动");
            Pos next;
            if (hero.MoveTo(hero.attackPos, next)) {
                nextAction.InitMove(next);
                return true;
            }
        }
    }
    vector<EnemyType> targetList = {ENEMY_HERO, ENEMY_SOLDIER, ENEMY_BUILDING};
    for (auto targetType : targetList) {
        if (hero.FindTarget(targetType, targetPos)) {
            if (GameContext::Instance().GetRoundMap().GetValue(targetPos) == SOLDIER) {
                // 对小兵先尝试使用神之一手
                for (auto& equip : hero.GetHeroInfo().equipments) {
                    if (equip.type == AGHANIM_SCEPTER && equip.cdRemain < 0) {
                        nextAction.InitUseEquip(AGHANIM_SCEPTER, targetPos);
                        PRINT_WARN("使用神之一手打人咯~");
                        return true;
                    }
                }
            }
            // 如果有金箍棒，则先使用
            for (auto& equip : hero.GetHeroInfo().equipments) {
                if (equip.type == MONKEY_KING_BAR && equip.cdRemain < 0) {
                    nextAction.InitUseEquip(MONKEY_KING_BAR);
                    PRINT_WARN("使用金箍棒打人咯~");
                    return true;
                }
            }
            nextAction.InitAttack(targetPos);
            return true;
        }
    }

    vector<AttackTarget> allTarget = FindTarget(hero.GetPos(), MAX_DISTANCE_ATTACK);
    if (allTarget.empty()) {
        PRINT_WARN("周围没有可以主动发起攻击的目标");
        return false;
    }
    // 对目标进行排序，向第一个目标移动
    std::sort(allTarget.begin(), allTarget.end(), CompareTarget);
    Pos next;
    AttackTarget& attackTarget = allTarget[0];
    if ((attackTarget.hp <= hero.GetHeroInfo().hp || attackTarget.type == ENEMY_BUILDING)&& hero.MoveTo(attackTarget.pos, next)) {
        PRINT_ERROR("向可以主动攻击的目标移动");
        nextAction.InitMove(next);
        return true;
    }
    return false;
}

// 找到一定距离内的目标
vector<AttackTarget> AttackStrategy::FindTarget(Pos myPos, int maxDistance)
{
    GameContext ins = GameContext::Instance();
    vector<AttackTarget> ans;

    bool isInOppBuild = false;
    // 判断当前英雄有没有在对方塔里
    for (auto& build : ins.GetOppDefenseTower()) {
        for (int i = 0; i < 4; i ++ ) {
            if (build.poses[i].CalcDistance(myPos, MANHATTAN) <= 4) isInOppBuild = true;
        }
    }

    // 敌方英雄
    for (const auto& oppHero : ins.GetOppHeroInfo()) {
        int distance = myPos.CalcDistance(oppHero.pos, CHEBYSHEV);
        if (!oppHero.isDead && oppHero.status.phyDamageImmu == -1 && distance <= maxDistance && !isInOppBuild) {
            AttackTarget target;
            target.pos = oppHero.pos;
            target.distance = distance;
            target.hp = oppHero.hp;
            target.type = ENEMY_HERO;
            ans.push_back(target);
        }
    }

    // 小兵
    for (const auto& oppSoldier : ins.GetOppSoldiers()) {
        int distance = myPos.CalcDistance(oppSoldier.pos, CHEBYSHEV);
        if (distance <= maxDistance && oppSoldier.status.phyDamageImmu == -1) {
            AttackTarget target;
            target.pos = oppSoldier.pos;
            target.distance = distance;
            target.hp = oppSoldier.hp;
            target.type = ENEMY_SOLDIER;
            ans.push_back(target);
        }
    }

    for (auto oppTower : ins.GetOppDefenseTower()) {
        if (!ins.IsMySoldierInRange(oppTower)) {
            PRINT_DEBUG("防御塔内没有我方小兵，跳过");
            continue;
        }
        int distance = myPos.CalcDistance(oppTower.poses[0], CHEBYSHEV);
        if (distance <= maxDistance) {
            AttackTarget target;
            target.pos = oppTower.poses[0];
            target.distance = distance;
            target.hp = oppTower.hp;
            target.type = ENEMY_BUILDING;
            ans.push_back(target);
        }
    }
    return ans;
}
