#pragma once

#include "hero_strategy.h"
#include "game_context.h"

class PatrolStrategy : public HeroStrategy {
public:
    bool DecideNextAction(Hero& hero, Action& nextAction) override;
};