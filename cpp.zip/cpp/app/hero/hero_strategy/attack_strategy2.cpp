#include <algorithm>
#include "attack_strategy2.h"
#include "log.h"
#include "game_config.h"
#include "game_context.h"

static bool CompareTarget(const AttackTarget2& a, const AttackTarget2& b)
{
    // 先按照类型排序
    if (a.type != b.type) {
        return a.type < b.type;
    }
    // 再按照血量排序
    if (a.hp != b.hp) {
        return a.hp < b.hp;
    }
    // 按照距离排序
    return a.distance < b.distance;
}

bool AttackStrategy2::DecideNextAction(Hero& hero, Action& nextAction)
{
    PRINT_INFO("enter");
    Pos targetPos;

    if (!hero.CanAttack()) {
        return false;
    }

    // if (hero.haveAttackPos) {
    //     PRINT_WARN("有建议攻击的目标");
    //     if (hero.GetCharacter()->CanAttackHero(hero.GetPos(), hero.attackPos)) {
    //         PRINT_WARN("普通攻击%s", hero.attackPos.toString().c_str());
    //         nextAction.InitAttack(hero.attackPos);
    //         return true;
    //     } else {
    //         PRINT_WARN("向建议攻击目标移动");
    //         Pos next;
    //         if (hero.MoveTo(hero.attackPos, next)) {
    //             nextAction.InitMove(next);
    //             return true;
    //         }
    //     }
    // }
    vector<EnemyType> targetList = {ENEMY_BUILDING};
    for (auto targetType : targetList) {
        if (hero.FindTarget(targetType, targetPos)) {
            // 如果有金箍棒，则先使用
            for (auto& equip : hero.GetHeroInfo().equipments) {
                if (equip.type == MONKEY_KING_BAR && equip.cdRemain < 0) {
                    nextAction.InitUseEquip(MONKEY_KING_BAR);
                    PRINT_WARN("使用金箍棒打人咯~");
                    return true;
                }
            }
            nextAction.InitAttack(targetPos);
            return true;
        }
    }

    vector<AttackTarget2> allTarget = FindTarget(hero, hero.GetPos(), MAX_DISTANCE_ATTACK);
    if (allTarget.empty()) {
        PRINT_WARN("周围没有可以主动发起攻击的目标");
        return false;
    }

    // 对目标进行排序，向第一个目标移动
    std::sort(allTarget.begin(), allTarget.end(), CompareTarget);
    Pos next;
    AttackTarget2& attackTarget = allTarget[0];
    if ((attackTarget.hp <= hero.GetHeroInfo().hp || attackTarget.type == ENEMY_BUILDING)&& hero.MoveTo(attackTarget.pos, next)) {
        PRINT_ERROR("向可以主动攻击的目标移动");
        nextAction.InitMove(next);
        return true;
    }
    return false;
}

// 找到一定距离内的目标
vector<AttackTarget2> AttackStrategy2::FindTarget(Hero& hero, Pos myPos, int maxDistance)
{
    GameContext ins = GameContext::Instance();
    vector<AttackTarget2> ans;



    for (auto oppTower : ins.GetOppDefenseTower()) {
        if (!ins.IsMySoldierInRange(oppTower)) {
            PRINT_DEBUG("防御塔内没有我方小兵，跳过");
            continue;
        }
        
        int distance = myPos.CalcDistance(oppTower.poses[0], CHEBYSHEV);
        if (distance <= maxDistance && distance <= hero.GetHeroInfo().atkDis) {
            AttackTarget2 target;
            target.pos = oppTower.poses[0];
            target.distance = distance;
            target.hp = oppTower.hp;
            target.type = ENEMY_BUILDING;
            ans.push_back(target);
        }
    }
    return ans;
}
