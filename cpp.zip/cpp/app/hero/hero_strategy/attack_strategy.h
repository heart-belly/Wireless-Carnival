#pragma once

#include "hero_strategy.h"

// 可以攻击的目标类型
struct AttackTarget {
    Pos pos;
    int distance;
    int hp = 0;
    EnemyType type = ENEMY_HERO;
};

class AttackStrategy : public HeroStrategy {
public:
    bool DecideNextAction(Hero& hero, Action& nextAction) override;
    vector<AttackTarget> FindTarget(Pos myPos, int distance);
};