#include "opening_strategy.h"
#include "game_config.h"

bool OpeningStrategy::DecideNextAction(Hero& hero, Action& nextAction)
{
    PRINT_INFO("enter");
    GameContext ins = GameContext::Instance();
    Pos targetPos1, targetPos2;
    Pos nextPos;


    int sz = ins.GetOppAliveHeroInfo().size();
    if (sz > 0 || ins.GetRound() > 990) {
        isCanGo = true;
        isUseOpenStrategy = false;
    }

    // 不用使用开局策略
    if (!isUseOpenStrategy) return false;


    Hero* teammate = ins.GetTeammate(hero);
    Pos targetPos;

    if (hero.GetHeroKind() == HERO_BACK) {
            if (teammate == nullptr || teammate->IsDead()) {
                PRINT_ERROR("nullptr or dead");
            } else {
                targetPos = teammate->GetPos();
                if (hero.GetPos().CalcDistance(targetPos, CHEBYSHEV) <= DISTANCE_TEAMMATE) {
                    // 让该英雄也进草从
                    targetPos1 = Pos{22, 1}, targetPos2 = Pos{23, 1};
                    if (targetPos == targetPos1 || targetPos == targetPos2) {
                        Pos mytargetPos = targetPos  == targetPos1 ? targetPos2 : targetPos1; 
                        if (hero.MoveTo(mytargetPos, nextPos)) {
                            PRINT_INFO("移动进入草丛");
                            nextAction.InitMove(nextPos);
                            return true;  
                        } 
                    }

                    if (hero.MoveTo(targetPos, nextPos)) {
                        PRINT_INFO("后排跟随前排移动");
                        nextAction.InitMove(nextPos);
                        return true;
                    }
                }
            }
        }

    // 使用开局策略（主要应对对方英雄走中路问题）

    // 如果草丛在指定位置则移动过去（固定地图：(20, 14). (20, 15)
    // 两个英雄走到目标草丛位置
    Map map = ins.GetinitMap();
    // 得到英雄的坐标
    Pos myPos = hero.GetPos();
    if ((map.mapValue_[1][22] == 2 && map.mapValue_[1][23] == 2)) {
        // 指定位置为草丛，让英雄走过去
        targetPos1 = Pos{22, 1}, targetPos2 = Pos{23, 1};
        if (map.mapValue_[hero.GetPos().y_][hero.GetPos().x_] == 2) {
            PRINT_INFO("开局的特殊策略，已经在草丛，位置为%s", hero.GetPos().toString().c_str());
            nextAction.InitIdle();
            return true;
        }

        if (!hero.MoveTo(targetPos1, nextPos) && !hero.MoveTo(targetPos2, nextPos)) {
            return false;
        }

        PRINT_INFO("自己的位置为%s", hero.GetPos().toString().c_str());
        PRINT_INFO("开局的特殊策略，目标是%s 或者是%s", targetPos1.toString().c_str(), targetPos2.toString().c_str());
        nextAction.InitMove(nextPos);
        return true;
    } 





    return false;






    // // 如果我方防御塔下有敌方小兵，则移动或传送到我方防御塔
    // for (const auto& myTower : ins.GetMyDefenseTower()) {
    //     if (ins.IsOppSoldierInRange(myTower) && myTower.hp < 600) {
    //         PRINT_WARN("我方防御塔下有敌人，向防御塔移动");
    //         // 我方基地和防御塔统一为右上角
    //         if (hero.MoveTo(myTower.poses[3], nextPos)) {
    //             nextAction.InitMove(nextPos);
    //             return true;
    //         }
    //     }
    // }
   
    // // 找到走的最远的小兵（就近原则）
    // // 判断当前机器人的位置在下方还是上方

    // int maxDistance = 0;
    // bool find = false;
    // int pos = -1; //  up : 0; down : 1;
    // if (hero.GetPos().y_ < ins.GetRoundMap().maxY / 2) pos = 1;
    // else {
    //     pos = 0;
    // }

    // for (const auto& mySoldier : ins.GetMySoldiers()) {
    //     if (pos == 0) {
    //         if (mySoldier.pos.y_ > ins.GetRoundMap().maxY / 2) {
    //             // 找到距离本方基地最远的小兵
    //             int tmp = abs(mySoldier.pos.x_ - ins.GetMyBase()->detail.poses[0].x_);
    //             if (tmp > maxDistance) {
    //                 find = true;
    //                 maxDistance = tmp;
    //                 targetPos = mySoldier.pos;
    //             }
    //         }
    //     } else if (pos == 1) {
    //         if (mySoldier.pos.y_ < ins.GetRoundMap().maxY / 2) {
    //             // 找到距离本方基地最远的小兵
    //             int tmp = abs(mySoldier.pos.x_ - ins.GetMyBase()->detail.poses[0].x_);
    //             if (tmp > maxDistance) {
    //                 find = true;
    //                 maxDistance = tmp;
    //                 targetPos = mySoldier.pos;
    //             }
    //         }            
    //     }
    // }

    // // 如果走过中线，或者已经和敌方小兵相遇，则跟随兵线
    // if (find) {
    //     bool needFollow = false;
    //     for (auto tmp : ins.GetOppSoldiers()) {
    //         if (targetPos.CalcDistance(tmp.pos, CHEBYSHEV) <= 5) {
    //             PRINT_WARN("上路兵线即将相遇");
    //             needFollow = true;
    //         }
    //     }

    //     // 判断敌方英雄是否出现在视野里
    //     int isSeeCnt = 0;
    //     for (int i = 0; i < ins.GetOppAliveHeroInfo().size(); i ++ ) {
    //         isSeeCnt ++;
    //     }

    //     if (isSeeCnt > 0) isCanGo = true;

    //     if (((needFollow || maxDistance > 12) && isCanGo)) {
    //         // 根据英雄的前后排类型，选择站位
    //         Pos offset;
    //         if (hero.GetHeroKind() == HERO_FRONT) {
    //             offset = Pos(0 * ins.GetDirection(), 1);
    //         } else {
    //             offset = Pos(-1 * ins.GetDirection(), 1);
    //         }
    //         targetPos = targetPos + offset;
    //         if (!hero.MoveTo(targetPos, nextPos)) {
    //             return false;
    //         }
    //         PRINT_INFO("跟随兵线移动，目标是%s", targetPos.toString().c_str());
    //         nextAction.InitMove(nextPos);
    //         return true;
    //     }
    // }


    // // 优先向离当前位置最近的防御塔移动
    // const vector<TowerDetail>& myTowers = ins.GetMyTowers();
    // if (myTowers.size() == 2) {
    //     // 记录防御塔距离当前英雄的距离
    //     int dist[2] = {0};
    //     for (int i = 0; i < myTowers.size(); ++ i ) {
    //         dist[i] = hero.GetPos().CalcDistance(myTowers[i].poses[3], CHEBYSHEV);
    //     }

    //     TowerDetail myTower = dist[0] < dist[1] ? myTowers[0] : myTowers[1];

    //     // 优先去最近的防御塔
    //     if (hero.GetPos().CalcDistance(myTower.poses[0], CHEBYSHEV) > 7) {
    //         for (auto& equip : hero.GetHeroInfo().equipments) {
    //             if (equip.type == BOOTS_OF_TRAVEL && equip.cdRemain < 0) {
    //                 // 找到塔周围两格以内的空地
    //                 const vector<Pos>& neighbor = myTower.poses[2].GetNeighbor();
    //                 for (auto tmp : neighbor) {
    //                     if (ins.GetRoundMap().IsReachable(tmp)) {
    //                         nextAction.InitUseEquip(BOOTS_OF_TRAVEL, tmp);
    //                         PRINT_WARN("开始传送~");
    //                         return true;
    //                     }
    //                 }
    //             }
    //         }
    //     }

    //     if (hero.MoveTo(myTower.poses[2], nextPos)) {
    //         // PRINT_INFO("ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n");
    //         nextAction.InitMove(nextPos);
    //         return true;
    //     }


        // for (auto myTower : myTowers) {
        //     if (myTower.poses[0].y_ > 15) {
        //         // 找到了上路塔
        //         // 如果距离远，有TP，则传送到防御塔
        //         if (hero.GetPos().CalcDistance(myTower.poses[0], CHEBYSHEV) > 7) {
        //             for (auto& equip : hero.GetHeroInfo().equipments) {
        //                 if (equip.type == BOOTS_OF_TRAVEL && equip.cdRemain < 0) {
        //                     // 找到塔周围两格以内的空地
        //                     const vector<Pos>& neighbor = myTower.poses[0].GetNeighbor();
        //                     for (auto tmp : neighbor) {
        //                         if (ins.GetRoundMap().IsReachable(tmp)) {
        //                             nextAction.InitUseEquip(BOOTS_OF_TRAVEL, tmp);
        //                             PRINT_WARN("开始传送~");
        //                             return true;
        //                         }
        //                     }
        //                 }
        //             }
        //         }

        //         if (hero.MoveTo(myTower.poses[0], nextPos)) {
        //             nextAction.InitMove(nextPos);
        //             return true;
        //         }
        //     }
        // }


    return false;
}