#pragma once

#include "hero_strategy.h"
class CastSkillStrategy : public HeroStrategy {
public:
    bool DecideNextAction(Hero &hero, Action &nextAction) override;
};