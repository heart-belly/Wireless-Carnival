#include "revive_strategy.h"
#include "game_config.h"

bool ReviveStrategy::DecideNextAction(Hero& hero, Action& nextAction)
{
    PRINT_INFO("enter");
    GameContext ins = GameContext::Instance();
    auto& heroTemp = hero.GetHeroInfo();

    if (heroTemp.money < heroTemp.buyLiveCost || heroTemp.buyLiveRemainRound != -1) return false;



    // 敌方英雄在塔下攻击塔
    for (const auto& myTower : ins.GetMyDefenseTower()) {
        if (ins.GetOppSoldierInRangeNumber(myTower) >= 2 && ins.GetOppSoldierInRangeNumber(myTower) >= 1) {
            if (heroTemp.isDead) {
                nextAction.InitRevive();  
                PRINT_INFO("use Revive");
                return true;              
            }
        }
    
    }

    // 得到对方英雄的存活个数
    int oppAliveNUmber = ins.GetOppAliveHeroInfo().size();
    if (heroTemp.isDead && heroTemp.reviveRound >= 15 && ((hero.getUseRevive() < 2 && oppAliveNUmber == 2) || (oppAliveNUmber <= 1 && heroTemp.equipments.size() >= 2))) {
        hero.setUserRevive();
        nextAction.InitRevive();
        PRINT_INFO("use Revive");
        return true;
    }

    return false;







  






}