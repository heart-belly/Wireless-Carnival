#include "debug_strategy.h"
#include "game_context.h"
#include "attack_strategy.h"
#include "buy_equip_strategy.h"
#include "escape_strategy.h"
#include "game_config.h"

bool DebugStrategy::DecideNextAction(Hero& hero, Action& nextAction)
{
    PRINT_INFO("enter");
    return false;

    if (!TestEscape(hero, nextAction)) {
        nextAction.InitIdle();
    }
    return true;
}

bool DebugStrategy::TestEscape(Hero& hero, Action& nextAction)
{
    GameContext& context = GameContext ::Instance();
    const Pos& target1 = Pos(0, 0);
    const Pos& target2 = Pos(0, 14);
    const Pos& src1 = Pos(46, 15);
    const Pos& src2 = Pos(0, 0);

    Pos target;
    Pos src;
    if (hero.GetHeroInfo().heroType == g_clientHero1) {
        target = target1;
        src = src1;
    } else {
        target = target2;
        src = src2;
    }

    if (context.GetOwnPlayerId() == 2222) {
        Pos next;
        if (hero.MoveTo(target, next)) {
            nextAction.InitMove(next);
            return true;
        }
    } else {
        unique_ptr<EscapeStrategy> pStrategy = make_unique<EscapeStrategy>();
        if (pStrategy->DecideNextAction(hero, nextAction)) {
            return true;
        }
        Pos next;
        if (hero.MoveTo(src, next)) {
            nextAction.InitMove(next);
            return true;
        }
    }
    return false;
}

/*
 * 两个英雄在狙击或霰弹范围内时，优先攻击血量低的英雄
 */
bool DebugStrategy::TestRifleman1(Hero& hero, Action& nextAction)
{
    GameContext& context = GameContext ::Instance();
    const Pos& target2 = Pos(31, 9);
    const Pos& target1 = Pos(31, 15);
    const Pos& src1 = Pos(24, 15);
    const Pos& src2 = Pos(29, 12);

    Pos target;
    Pos src;
    if (hero.GetHeroInfo().heroType == g_clientHero1) {
        target = target1;
        src = src1;
    } else {
        target = target2;
        src = src2;
    }

    if (context.GetOwnPlayerId() == 2222) {
        Pos next;

        // 如果被瞄准，向右侧移动一格
        if (hero.GetHeroInfo().status.targeted != -1) {
            PRINT_WARN("我被瞄准了，开始跑");
            next = hero.GetPos() + Pos(1, 0);
            nextAction.InitMove(next);
            return true;
        }
        if (hero.MoveTo(target, next)) {
            nextAction.InitMove(next);
            return true;
        }
    } else {
        // 先移动到指定位置，然后再施法
        Pos next;
        if (hero.MoveTo(src, next)) {
            nextAction.InitMove(next);
            return true;
        }
        if (hero.CastSkill(nextAction)) {
            return true;
        }
    }
    return false;
}

/*
 * 两个英雄在普攻范围内时，优先攻击血量低的英雄
 */
bool DebugStrategy::TestRifleman2(Hero& hero, Action& nextAction)
{
    GameContext& context = GameContext ::Instance();
    const Pos& target2 = Pos(31, 9);
    const Pos& target1 = Pos(31, 15);
    const Pos& src1 = Pos(29, 12);
    const Pos& src2 = Pos(0, 0);

    Pos target;
    Pos src;
    if (hero.GetHeroInfo().heroType == g_clientHero1) {
        target = target1;
        src = src1;
    } else {
        target = target2;
        src = src2;
    }

    if (context.GetOwnPlayerId() == 2222) {
        Pos next;

        if (hero.MoveTo(target, next)) {
            nextAction.InitMove(next);
            return true;
        }
    } else {
        // 先移动到指定位置，然后再攻击
        Pos next;
        if (hero.MoveTo(src, next)) {
            nextAction.InitMove(next);
            return true;
        }

        if (hero.GetHeroInfo().heroType == g_clientHero1) {
            auto* pStrategy = new AttackStrategy();
            if (pStrategy->DecideNextAction(hero, nextAction)) {
                return true;
            }
        }
    }
    return false;
}

bool DebugStrategy::TestBuy(Hero& hero, Action& action)
{
    unique_ptr<BuyEquipStrategy> pStrategy = make_unique<BuyEquipStrategy>();
    return pStrategy->DecideNextAction(hero, action);
}
