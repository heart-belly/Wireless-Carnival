#include "team_ai.h"
#include "game_context.h"

/*
 * 事件
 * 遭遇对方英雄
 * 兵线即将相遇
 * 敌方进入防御塔
 */

void TeamAi::DecideTeamAction(vector<HeroAction>& teamAction)
{
    // 通知每个英雄根据当前的信息，决策下一步的action，并发送给服务器
    GameContext ins = GameContext::Instance();

    // 如果两个英雄都存活，分析团队策略
//     bool find = false;
//     Pos targetPos;
//     if (ins.GetMyAliveHeroes().size() == 2) {
//         // 找到距离我方两个英雄最近的敌方英雄，都去打它
//         int minDistance = INT32_MAX;
//         Hero* hero1 = ins.GetMyAliveHeroes()[0];
//         Hero* hero2 = ins.GetMyAliveHeroes()[1];
//         for (auto& oppHero : ins.GetOppAliveHeroInfo()) {
//             if (oppHero.status.phyDamageImmu >= 0 || oppHero.status.magicDamageImmu >= 0) {
//                 continue;
//             }
//             int distance1 = hero1->GetPos().CalcDistance(oppHero.pos, CHEBYSHEV);
//             int distance2 = hero2->GetPos().CalcDistance(oppHero.pos, CHEBYSHEV);
//             int myHp = hero1->GetHeroInfo().hp + hero2->GetHeroInfo().hp;
//             int sum = distance1 + distance2;
//             if (sum <= 12 && sum < minDistance && myHp > oppHero.hp) {
//                 minDistance = sum;
//                 targetPos = oppHero.pos;
//                 find = true;
//             }
//         }
//
//         if (find) {
//             PRINT_WARN("距离我方最近的敌方英雄位置是%s，距离是%d", targetPos.toString().c_str(), minDistance);
//         }
//     }

    for (auto& curHero : ins.GetMyHeroes()) {
        const HeroInfo& heroInfo = curHero->GetHeroInfo();
        PRINT_WARN("cur heroType info: %s", heroInfo.ToString().c_str());

        HeroAction heroAction;
        heroAction.id = curHero->GetId();

        if (heroInfo.isDead) {
            PRINT_WARN("cur hero is dead, do nothing");
            heroAction.action.InitIdle();
        } else {
//             if (find) {
//                 curHero->attackPos = targetPos;
//                 curHero->haveAttackPos = true;
//             } else {
//                 curHero->haveAttackPos = false;
//             }
            curHero->DecideNextAction(heroAction.action);
        }
        teamAction.push_back(heroAction);
    }
}