#include "dark_seer.h"
#include "game_context.h"

DarkSeer::DarkSeer() : HeroCharacter(DARK_SEER) {}

bool DarkSeer::CastSkill(Hero& hero, Action& action)
{
    GameContext ins = GameContext::Instance();

    if (CastOneSkill(hero, POISON_TOUCH, action)) {
        return true;
    }

    const Skill* skillInfo = hero.GetRoundSkillInfo(SHALLOW_GRAVE);
    if (skillInfo->cdRemainRound >= 0) {
        return false;
    }

    if (hero.IsUnderAttack()) {
        PRINT_ERROR("暗牧在被攻击，对自己释放薄葬");
        action.InitSkill(SHALLOW_GRAVE, hero.GetPos());
        return true;
    }

    // 如果距离3内有己方英雄，且血量正在减少，则对其释放薄葬
    Hero* teammate = ins.GetTeammate(hero);
    if (teammate != nullptr && !teammate->IsDead()) {
        const Pos& teammatePos = teammate->GetPos();
        int distance = hero.GetPos().CalcDistance(teammatePos, CHEBYSHEV);
        if (teammate->IsUnderAttack()) {
            PRINT_ERROR("队友在被攻击");
            if (distance <= 3) {
                PRINT_ERROR("队友血量减少，向队友释放薄葬");
                action.InitSkill(SHALLOW_GRAVE, teammatePos);
                return true;
            }
            if (distance <= 6) {
                Pos next;
                if (hero.MoveTo(teammatePos, next)) {
                    PRINT_ERROR("暗牧向队友移动");
                    action.InitMove(next);
                    return true;
                }
            }
        }
    }

    return false;
}
