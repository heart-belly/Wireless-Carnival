#pragma once

#include "hero_character.h"

class DarkSeer : public HeroCharacter{
public:
    DarkSeer();
    bool CastSkill(Hero& hero, Action& action) override;
};