#include "crystal_maiden.h"
#include "game_context.h"

CrystalMaiden::CrystalMaiden() : HeroCharacter(CRYSTAL_MAIDEN) {}

bool CrystalMaiden::CastSkill(Hero& hero, Action& action)
{
    GameContext& ins = GameContext::Instance();

    const Skill* skillInfo = hero.GetRoundSkillInfo(FREEZING_FIELD);
    // 如果还在持续施法状态，需要判断是否继续施法
    if (skillInfo->durationRemainRound >= 0) {
        // 检查技能覆盖范围内，是否有敌方的英雄、小兵或者野怪
        PRINT_WARN("当前极寒领域还在持续施法状态，剩余%d轮", skillInfo->durationRemainRound);
        for (auto tmp : ins.GetOppUnit()) {
            Pos releasePos;
            if (IsInSkillRange(hero.GetPos(), tmp.pos, FREEZING_FIELD, releasePos)) {
                PRINT_WARN("技能范围内存在敌方单位 %s %d，继续施法", tmp.pos.toString().c_str(), tmp.type);
                action.InitIdle();
                return true;
            }
        }
    }

    skillInfo = hero.GetRoundSkillInfo(FROSTBITE);
    if (skillInfo->cdRemainRound >= 0) {
        PRINT_INFO("冰封禁止冷却中，无法释放：cdRemainRound %d", skillInfo->cdRemainRound);
    } else {
        if (hero.haveAttackPos) {
            PRINT_WARN("有建议攻击的目标");
            if (hero.GetPos().CalcDistance(hero.attackPos, CHEBYSHEV) <= 3) {
                PRINT_WARN("向%s释放冰封禁止", hero.attackPos.toString().c_str());
                action.InitSkill(FROSTBITE, hero.attackPos);
                return true;
            } else {
                PRINT_WARN("向建议攻击目标移动");
                Pos next;
                if (hero.MoveTo(hero.attackPos, next)) {
                    action.InitMove(next);
                    return true;
                }
            }
        }
    }

    skillInfo = hero.GetRoundSkillInfo(FREEZING_FIELD);
    if (skillInfo->cdRemainRound >= 0) {
        PRINT_INFO("极寒领域冷却中，无法释放：cdRemainRound %d", skillInfo->cdRemainRound);
    } else {
        if (hero.haveAttackPos) {
            PRINT_WARN("有建议攻击的目标");
            if (hero.GetPos().CalcDistance(hero.attackPos, CHEBYSHEV) <= 3) {
                // 先尝试使用黑皇杖，避免施法时被打断
                for (auto& equip : hero.GetHeroInfo().equipments) {
                    if (equip.type == BLACK_KING_BAR && equip.cdRemain < 0) {
                        action.InitUseEquip(BLACK_KING_BAR);
                        return true;
                    }
                }
                // 如果有绿杖，则先使用
                for (auto& equip : hero.GetHeroInfo().equipments) {
                    if (equip.type == GHOST_SCEPTER && equip.cdRemain < 0) {
                        action.InitUseEquip(GHOST_SCEPTER);
                        return true;
                    }
                }
                PRINT_WARN("向%s释放极寒领域", hero.attackPos.toString().c_str());
                action.InitSkill(FREEZING_FIELD, Pos(0, 0));
                return true;
            } else {
                PRINT_WARN("向建议攻击目标移动");
                Pos next;
                if (hero.MoveTo(hero.attackPos, next)) {
                    action.InitMove(next);
                    return true;
                }
            }
        }
    }

    if (hero.haveAttackPos) {
        return false;
    }

    if (CastOneSkill(hero, FROSTBITE, action)) {
        return true;
    }

    return CastOneSkill(hero, FREEZING_FIELD, action);
}

vector<EquipType> CrystalMaiden::GetBuyEquipList() const
{
    vector<EquipType> ans = {AGHANIM_SCEPTER, MONKEY_KING_BAR, BOOTS_OF_TRAVEL};
    return ans;
}