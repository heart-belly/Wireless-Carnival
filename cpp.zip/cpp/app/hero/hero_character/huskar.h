#pragma once

#include "hero_character.h"

class Huskar : public HeroCharacter{
public:
    Huskar();
    bool CastSkill(Hero &hero, Action &action) override;
    bool IsSkillInCd(const Hero& hero, SkillId skillId) const;
};