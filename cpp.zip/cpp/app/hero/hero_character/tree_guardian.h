#pragma once

#include "hero_character.h"

class TreeGuardian : public HeroCharacter {
public:
    bool CastSkill(Hero &hero, Action &action) override;
    TreeGuardian();
};