#pragma once

#include "hero_character.h"

class Pudge : public HeroCharacter {
public:
    Pudge();
    bool CastSkill(Hero& hero, Action& action) override;
};