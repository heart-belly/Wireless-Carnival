#pragma once

#include "hero_character.h"

class CrystalMaiden : public HeroCharacter {
public:
    CrystalMaiden();
    bool CastSkill(Hero &hero, Action &action) override;
    vector<EquipType> GetBuyEquipList() const override;
};
