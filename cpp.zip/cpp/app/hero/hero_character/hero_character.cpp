#include <algorithm>
#include "hero_character.h"
#include "game_context.h"
#include "pudge.h"
#include "crystal_maiden.h"
#include "lina.h"
#include "tree_guardian.h"
#include "rifleman.h"
#include "bfs.h"
#include "dark_seer.h"
#include "huskar.h"

unique_ptr<HeroCharacter> HeroCharacter::CreateHero(HeroType type)
{
    switch (type) {
        case PUDGE:
            return make_unique<Pudge>();
        case TREANT_PROTECTOR:
            return make_unique<TreeGuardian>();
        case LINA:
            return make_unique<Lina>();
        case CRYSTAL_MAIDEN:
            return make_unique<CrystalMaiden>();
        case SNIPER:
            return make_unique<Rifleman>();
        case DARK_SEER:
            return make_unique<DarkSeer>();
        case HUSKAR:
            return make_unique<Huskar>();
        default:
            PRINT_ERROR("unknown heroType type %d", type);
            return nullptr;
    }
}

bool HeroCharacter::CanAttackHero(Pos mine, Pos target) const
{
    return CanAttackHero(mine, target, 0);
}

bool HeroCharacter::CanAttackHero(Pos mine, Pos target, int addDistance) const
{
    return mine.IsNeighbor(target, heroCfg_->attackHeroDistance + addDistance, heroCfg_->attackType);
}

bool HeroCharacter::CanAttackOther(Pos mine, Pos target) const
{
    return mine.IsNeighbor(target, heroCfg_->attackDistance, heroCfg_->attackType);
}

string HeroCharacter::GetName() const
{
    return GetHeroName(heroType_);
}

static bool CompareByHeroHp(const HeroInfo& a, const HeroInfo& b)
{
    return a.hp < b.hp;
}

static bool CompareBySoldierHp(const SoldierDetail& a, const SoldierDetail& b)
{
    return a.hp < b.hp;
}

/*
 * 当前英雄释放某个技能
 * 1、如果技能还未冷却，则返回false
 * 2、如果技能覆盖范围内存在目标，则施法
 *      2.1、优先攻击英雄
 *      2.1、优先选择血量小的目标
 *      2.2、选择覆盖尽可能多的目标（暂不开发）
 */
bool HeroCharacter::CastOneSkill(Hero& hero, SkillId skillId, Action& action)
{
    GameContext& context = GameContext::Instance();
    vector<HeroInfo> oppHeroes = context.GetOppHeroInfo();
    vector<SoldierDetail> oppSoldiers = context.GetOppSoldiers();
    const SkillCfg* skillCfg = GetSkillCfg(skillId);
    const Skill* skillInfo = hero.GetRoundSkillInfo(skillId);
    Pos skillReleasePos;
    string skillName = GetSkillName(skillId);

    if (skillCfg == nullptr || skillInfo == nullptr) {
        PRINT_ERROR("skillCfg == nullptr or skillInfo == nullptr : skillId %d", skillId);
        return false;
    }

    // 当前技能的冷却时间必须小于0，才能释放
    if (skillInfo->cdRemainRound >= 0) {
        PRINT_INFO("cdRemainRound %d, can't cast skill", skillInfo->cdRemainRound);
        return false;
    }

    if (skillCfg->targetType == OPP_ALL || skillCfg->targetType == OPP_HERO) {
        // 按照血量高低进行排序，优先攻击血量少的
        std::sort(oppHeroes.begin(), oppHeroes.end(), CompareByHeroHp);

        for (const HeroInfo& oppHero : oppHeroes) {
            if (skillId == ASSASSINATE && oppHero.status.phyDamageImmu != -1) {
                continue;
            }

            if (!oppHero.isDead && hero.CanCastSkill(oppHero.pos, skillId, skillReleasePos)) {
                PRINT_WARN("对敌方英雄 %s %s 释放 %s，剩余血量 %d", GetHeroName((HeroType)oppHero.heroType).c_str(),
                           oppHero.pos.toString().c_str(), skillName.c_str(), oppHero.hp);
                action.InitSkill(skillId, skillReleasePos);
                return true;
            }
        }
    }
    // 得到敌方英雄的信息(只有对方有个英雄死亡才能对小兵使用技能)


    if ((skillCfg->targetType == OPP_ALL || skillCfg->targetType == OPP_SOLDIER)) {
        std::sort(oppSoldiers.begin(), oppSoldiers.end(), CompareBySoldierHp);
        for (const SoldierDetail& oppSoldier : oppSoldiers) {
            if (hero.CanCastSkill(oppSoldier.pos, skillId, skillReleasePos)) {
                PRINT_WARN("对敌方士兵 %s 释放 %s，剩余血量 %d", oppSoldier.pos.toString().c_str(), skillName.c_str(),
                           oppSoldier.hp);
                action.InitSkill(skillId, skillReleasePos);
                return true;
            }
        }
    }

    return false;
}

HeroCfg* HeroCharacter::GetHeroConfig() const
{
    return heroCfg_;
}

vector<EquipType> HeroCharacter::GetBuyEquipList() const
{
    vector<EquipType> ans = {AGHANIM_SCEPTER, BOOTS_OF_TRAVEL, MONKEY_KING_BAR};
    return ans;
}

HeroCharacter::HeroCharacter(HeroType heroType) : heroType_(heroType)
{
    heroCfg_ = GetHeroCfg(heroType);
    if (heroCfg_ == nullptr) {
        PRINT_ERROR("hero type %d error", heroType);
        throw runtime_error("错误的hero type");
    }
}
