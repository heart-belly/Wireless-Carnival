#include "huskar.h"
#include "game_context.h"

bool Huskar::CastSkill(Hero& hero, Action& action)
{
    GameContext& ins = GameContext::Instance();

    // 判断 大招	牺牲	第二优先级
    // 对指定位置使用后，自身减少剩余血量的25%，同时对该位置上的单位造成当前剩余血量的50%的伤害（向上取整）
    SkillId curSKill = LIFE_BREAK;
    if (!IsSkillInCd(hero, curSKill)) {
        // 计算收益，选择收益最高的英雄进行攻击
        int myReducedHp = hero.GetHeroInfo().hp * 25 / 100;
        int benefitMax = 0;
        Pos targetPos;
        vector<HeroInfo> oppHeroes = ins.GetOppHeroInfo();
        for (const auto& oppHero : oppHeroes) {
            Pos skillReleasePos;
            if (!oppHero.isDead && hero.CanCastSkill(oppHero.pos, curSKill, skillReleasePos)) {
                // 可以对该英雄释放技能，计算收益
                int oppReducedHp = oppHero.hp * 50 / 100;
                int benefit = oppReducedHp - myReducedHp;
                PRINT_ERROR("oppReducedHp %d myReducedHp %d benefit %d", oppReducedHp, myReducedHp, benefit);
                if (benefit > benefitMax) {
                    benefitMax = benefit;
                    targetPos = skillReleasePos;
                }
            }
        }

        if (benefitMax > 80) {
            PRINT_ERROR("收益很大 %d，释放牺牲", benefitMax);
            action.InitSkill(curSKill, targetPos);
            return true;
        }
    }

    // 判断小技能
    if (hero.GetHeroInfo().hp < 200) {
        return CastOneSkill(hero, INNER_FIRE, action);
    }
    return false;
}

bool Huskar::IsSkillInCd(const Hero& hero, SkillId skillId) const
{
    const Skill* skillInfo = hero.GetRoundSkillInfo(skillId);

    if (skillInfo == nullptr) {
        PRINT_ERROR("skillInfo == nullptr : skillId %d", skillId);
        return true;
    }

    // 当前技能的冷却时间必须小于0，才能释放
    if (skillInfo->cdRemainRound >= 0) {
        PRINT_INFO("cdRemainRound %d, can't cast skill", skillInfo->cdRemainRound);
        return true;
    }
    return false;
}

Huskar::Huskar() : HeroCharacter(HUSKAR) {}
