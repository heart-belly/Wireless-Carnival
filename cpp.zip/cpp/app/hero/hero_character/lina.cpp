#include "lina.h"

Lina::Lina() : HeroCharacter(LINA) {}

bool Lina::CastSkill(Hero& hero, Action& action)
{
    if (CastOneSkill(hero, LAGUNA_BLADE, action)) {
        return true;
    }
    return CastOneSkill(hero, LIGHT_STRIKE_ARRAY, action);
}

vector<EquipType> Lina::GetBuyEquipList() const
{
    vector<EquipType> ans = {AGHANIM_SCEPTER, MONKEY_KING_BAR, BOOTS_OF_TRAVEL};
    return ans;
}
