#include "tree_guardian.h"

TreeGuardian::TreeGuardian() : HeroCharacter(TREANT_PROTECTOR) {}

bool TreeGuardian::CastSkill(Hero& hero, Action& action)
{
    if (CastOneSkill(hero, NATURE_GRASP, action)) {
        return true;
    }
    return CastOneSkill(hero, LEECH_SEED, action);
}
