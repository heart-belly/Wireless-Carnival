#include "rifleman.h"
#include "game_context.h"

Rifleman::Rifleman() : HeroCharacter(SNIPER) {}

bool Rifleman::CastSkill(Hero& hero, Action& action)
{
    const Skill* skillInfo = hero.GetRoundSkillInfo(ASSASSINATE);
    if (skillInfo == nullptr) {
        PRINT_ERROR("don't find skill info for juji");
        return false;
    }

    // 如果狙击还在持续施法状态，需要检查
    if (skillInfo->durationRemainRound >= 0) {
        // 如果当前技能还在持续施法状态
        PRINT_WARN("当前狙击还在持续施法状态，剩余%d轮", skillInfo->durationRemainRound);
        // 检查是否有地方英雄处于被瞄准的状态
        const vector<HeroInfo>& oppHeroes = GameContext::Instance().GetOppHeroInfo();
        for (const auto& oppHero : oppHeroes) {
            if (oppHero.status.targeted != -1 && oppHero.status.phyDamageImmu == -1) {
                PRINT_WARN("对方英雄%s处于被瞄准的状态，继续持续施法", GetHeroName(oppHero.heroType).c_str());
                action.InitIdle();
                return true;
            }
        }
        PRINT_WARN("目标英雄已经超过了施法范围，停止持续施法");
    }

    if (skillInfo->cdRemainRound >= 0) {
        PRINT_INFO("狙击冷却中，无法释放：cdRemainRound %d", skillInfo->cdRemainRound);
    } else {
        if (hero.haveAttackPos) {
            PRINT_WARN("有建议攻击的目标");
            if (hero.GetPos().CalcDistance(hero.attackPos, MANHATTAN) <= 6) {
                PRINT_WARN("向%s释放狙击", hero.attackPos.toString().c_str());
                action.InitSkill(ASSASSINATE, hero.attackPos);
                return true;
            } else {
                PRINT_WARN("向建议攻击目标移动");
                Pos next;
                if (hero.MoveTo(hero.attackPos, next)) {
                    action.InitMove(next);
                    return true;
                }
            }
        }
    }

    skillInfo = hero.GetRoundSkillInfo(SHRAPNEL);
    if (skillInfo->cdRemainRound >= 0) {
        PRINT_INFO("榴霰弹冷却中，无法释放：cdRemainRound %d", skillInfo->cdRemainRound);
    } else {
        if (hero.haveAttackPos) {
            PRINT_WARN("有建议攻击的目标");
            Pos releasePos;
            if (IsInSkillRange(hero.GetPos(), hero.attackPos, SHRAPNEL, releasePos)) {
                PRINT_WARN("向%s释放榴霰弹", hero.attackPos.toString().c_str());
                action.InitSkill(SHRAPNEL, releasePos);
                return true;
            } else {
                return false;
            }
        }
    }

    if (hero.haveAttackPos) {
        return false;
    }

    if (CastOneSkill(hero, ASSASSINATE, action)) {
        return true;
    }
    return CastOneSkill(hero, SHRAPNEL, action);
}

vector<EquipType> Rifleman::GetBuyEquipList() const
{
    vector<EquipType> ans = {AGHANIM_SCEPTER, MONKEY_KING_BAR, BOOTS_OF_TRAVEL};
    return ans;
}
