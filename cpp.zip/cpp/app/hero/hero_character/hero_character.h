#pragma once

#include <string>
#include <utility>
#include "pos.h"
#include "json_type.h"
#include <memory>

using namespace std;

class Hero;

class HeroCharacter {
public:
    explicit HeroCharacter(HeroType heroType);
    virtual ~HeroCharacter() = default;  // 虚析构函数

    virtual bool CastSkill(Hero &hero, Action &action) = 0;
    virtual bool CanAttackOther(Pos mine, Pos target) const;
    virtual bool CanAttackHero(Pos mine, Pos target) const;
    virtual bool CanAttackHero(Pos mine, Pos target, int addDistance) const;
    // 释放单点技能
    bool CastOneSkill(Hero &hero, SkillId skillId, Action &action);
    string GetName() const;

    static unique_ptr<HeroCharacter> CreateHero(HeroType type);

protected:
    HeroType heroType_;
    HeroCfg *heroCfg_;

public:
    HeroCfg* GetHeroConfig() const;
    virtual vector<EquipType> GetBuyEquipList() const;
};