#include "pudge.h"
#include "log.h"

Pudge::Pudge() : HeroCharacter(PUDGE) {
}

bool Pudge::CastSkill(Hero&, Action&)
{
    return false;
}
