#pragma once

#include "hero_character.h"

class Rifleman : public HeroCharacter {
public:
    Rifleman();
    bool CastSkill(Hero &hero, Action &action) override;
    vector<EquipType> GetBuyEquipList() const override;
};