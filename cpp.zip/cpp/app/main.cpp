#include "main_process.h"
#include "game_context.h"
#include "socket_connect_fake.h"
#include <cstdlib>
#include <getopt.h>
#include "game_config.h"
#include "ctime"

struct Arguments {
    std::string runMode = "run";
    std::string replayFile = "replay.txt";
    int breakRound = 500;
    int isStepTo = 0;
    int playerId = 1111;
    std::string playerIp = "127.0.0.1";
    int playerPort = 6001;
};

Arguments parseArgs(int argc, char* argv[]) {
    Arguments args;
    int opt;
    int option_index = 0;
    static struct option long_options[] = {
        {"runMode", required_argument, 0, 'm'},
        {"replayFile", required_argument, 0, 'f'},
        {"breakRound", required_argument, 0, 'r'},
        {"isStepTo", required_argument, 0, 'o'},
        {"playerId", required_argument, 0, 'd'},
        {"playerIp", required_argument, 0, 'i'},
        {"playerPort", required_argument, 0, 'p'},
        {"help", no_argument, 0, 'h'},
        {0, 0, 0, 0}
    };

    while ((opt = getopt_long(argc, argv, "m:f:r:o:d:n:i:p:h", long_options, &option_index)) != -1) {
        switch (opt) {
            case 'm':
                args.runMode = optarg;
                break;
            case 'f':
                args.replayFile = optarg;
                break;
            case 'r':
                args.breakRound = std::atoi(optarg);
                break;
            case 'o':
                args.isStepTo = std::atoi(optarg);
                break;
            case 'd':
                args.playerId = std::atoi(optarg);
                break;
            case 'i':
                args.playerIp = optarg;
                break;
            case 'p':
                args.playerPort = std::atoi(optarg);
                break;
            case 'h':
            default:
                std::cout << "Usage: " << argv[0] << " [options]\n"
                          << "Options:\n"
                          << "  -m, --runMode      运行的模式，有run和test两种 (default: run)\n"
                          << "  -f, --replayFile   调测模式下replay文件的存放位置 (default: replay.txt)\n"
                          << "  -r, --breakRound  调测模式下需要快进到的回合数 (default: 500)\n"
                          << "  -o, --isStepTo     调测模式下是否直接跳转到对应回合 (default: 0)\n"
                          << "  -d, --playerId     玩家ID (default: 1111)\n"
                          << "  -i, --playerIp     链接到服务器的IP (default: 127.0.0.1)\n"
                          << "  -p, --playerPort   链接到服务器的端口 (default: 6001)\n"
                          << "  -h, --help          Show this help message\n";
                exit(0);
        }
    }

    return args;
}

int main(int argc, char *argv[])
{
#if WIN32
    // 设置控制台代码页为 65001 (UTF-8)
    SetConsoleOutputCP(CP_UTF8);
    // 设置 locale 为 UTF-8
    std::setlocale(LC_ALL, ".UTF-8");
#endif
        // 设置随机数种子
    std::srand(std::time(nullptr));
    Arguments args = parseArgs(argc, argv);

    // 必须在第一次调用PRINT系列打印前设置player id，否则日志文件创建的时候名字不对
    GameContext::Instance().SetOwnPlayerId(args.playerId);
    LOG_Init(args.playerId);

#if WIN32
    PRINT_INFO("WIN32 version");
#else
    PRINT_INFO("NOT WIN32 version");
#endif
    PRINT_INFO("%s %s", __DATE__, __TIME__);
    PRINT_INFO("Replay file: %s", args.replayFile.c_str());
    PRINT_INFO("Run mode: %s", args.runMode.c_str());
    PRINT_INFO("Replay round: %d",args.breakRound);
    PRINT_INFO("One round: %d",args.isStepTo);
    PRINT_INFO("Player ID: %d", args.playerId);
    PRINT_INFO("Player IP: %s", args.playerIp.c_str());
    PRINT_INFO("Player port: %d", args.playerPort);

    unique_ptr<SocketConnect> socketConnect;
    if (args.runMode == "test") {
        PRINT_WARN("进入调试模式");
        socketConnect = make_unique<SocketConnectFake>(args.replayFile);
        g_breakRound = args.breakRound;
        g_isStepTo = args.isStepTo != 0;
    } else {
        socketConnect = make_unique<SocketConnect>();
    }

    MainProcess mainProcess(std::move(socketConnect));
    if (mainProcess.Connect(args.playerId, args.playerIp, args.playerPort, TEAM_NAME) == -1) {
        return -1;
    }
    (void)mainProcess.Run();
    (void)mainProcess.Disconnect();
    return 0;
}