#include <ctime>
#include "main_process.h"
#include "server_msg.h"
#include "register_msg.h"

#define DATA_BUF_SIZE 500000
#define LEN_BUF_SIZE 10
MainProcess::MainProcess(std::unique_ptr<SocketConnect> socketConnect) : socketConnect_(std::move(socketConnect)) {}

MainProcess::~MainProcess(void) = default;

// 玩家注册消息
int MainProcess::Register(int teamId, string& teamName)
{
    /* 向server注册 */
    RegisterMsg registerMsg;
    registerMsg.playerId = teamId;
    registerMsg.name = teamName;
    registerMsg.version = "1.0";

    return socketConnect_->SendMsg(registerMsg);
}

int MainProcess::Connect(int myId, const string& serverIp, unsigned short serverPort, string name)
{
    if (socketConnect_->Connect(serverIp, serverPort) != 0) {
        return -1;
    }

    int ret = Register(myId, name);
    PRINT_INFO("register my info to server success, ret:%d.", ret);
    return 0;
}

static char g_bufferOfMsg[DATA_BUF_SIZE] = {'\0'};
static char g_bufferOfLen[LEN_BUF_SIZE] = {'\0'};
static int g_recvMsgNum;
int MainProcess::ProcessMsg()
{
    unique_ptr<ServerMsg> serverMsg = nullptr;

    // 从socket中读取消息，并解析出具体的消息类型，然后进行处理
    try {
        clock_t start, end;
        double cpuTimeUsed;

        start = clock();

        // 先从socket里面获取消息的长度
        socketConnect_->RecvMsg(g_bufferOfLen, MSG_LENTH_NUMBER);
        int msgSize = atoi(g_bufferOfLen);
        if (msgSize <= 0 || msgSize >= (DATA_BUF_SIZE - 1)) {
            PRINT_ERROR("recv msg size error %d", msgSize);
            return 1;
        }

        // 读取余下的数据部分
        socketConnect_->RecvMsg(g_bufferOfMsg, msgSize);
        g_bufferOfMsg[msgSize] = 0;

        PRINT_INFO("******************* RecvMsg len=%d", msgSize);
        PRINT_DEBUG("%s", g_bufferOfMsg);

        serverMsg = ServerMsg::Parse(g_bufferOfMsg);
        if (serverMsg == nullptr) {
            PRINT_ERROR("ServerMsg::Parse failed\n%s", g_bufferOfMsg);
            return 1;
        }
        int ret = serverMsg->Process(*socketConnect_);
        if (ret != 0) {
            PRINT_WARN("serverMsg->Process() failed: %d", ret);
            return 1;
        }

        end = clock();
        cpuTimeUsed = ((double)(end - start)) / CLOCKS_PER_SEC;
        PRINT_INFO("[TIME]g_recvMsgNum %d %lf end, cpuTimeUsed %lf", g_recvMsgNum++, (double)end / CLOCKS_PER_SEC,
                    cpuTimeUsed);
        return 0;
    } catch (Json::Exception& e) {
        PRINT_ERROR("ERROR msg:\n%s", g_bufferOfMsg);
        PRINT_ERROR("Json::Exception: %s", e.what());
    } catch (exception& e) {
        PRINT_ERROR("exception: %s", e.what());
    } catch (...) {
        PRINT_ERROR("expt");
    }
    return 1;
}

int MainProcess::Run()
{
    /* 进入游戏 */
    while (ProcessMsg() == 0) {
    }
    PRINT_INFO("ProcessMsg exit");
    return 0;
}

int MainProcess::Disconnect()
{
    (void)socketConnect_->Disconnect();
    return 0;
}
