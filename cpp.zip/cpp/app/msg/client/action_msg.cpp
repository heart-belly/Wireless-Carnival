#include "action_msg.h"
#include "json_name.h"

void ActionMsg::ToJsonStr(string &retJsonStr) const
{
    Json::Value msgData;

    msgData[JsonName::playerId] = playerId;
    msgData[JsonName::round] = round;

    for (int i = 0; i < heroActionList.size(); i++) {
        HeroAction curHero = heroActionList[i];

        msgData[JsonName ::heros][i][JsonName::id] = curHero.id;

        Json::Value &action = msgData[JsonName ::heros][i][JsonName::action];
        action[JsonName::type] = curHero.action.type;
        action[JsonName::EquipId] = curHero.action.useEquipId;
        action[JsonName::skillId] = curHero.action.skillId;
        action[JsonName::targetPos][0] = curHero.action.targetPos.x_;
        action[JsonName::targetPos][1] = curHero.action.targetPos.y_;
        int j = 0;
        for (EquipType toBuy : curHero.action.buyEquipIds) {
            action[JsonName::equipmentList][j++] = (int)toBuy;
        }
    }

    ClientMsg::BuildMsgStr(JsonName::action, msgData, retJsonStr);
}
