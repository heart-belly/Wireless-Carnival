#include "ready_msg.h"
#include "json_name.h"

void ReadyMsg::ToJsonStr(string &retJsonStr) const
{
    Json::Value msgData;

    msgData[JsonName::playerId] = playerId;

    ClientMsg::BuildMsgStr(JsonName::ready, msgData, retJsonStr);
}
