#pragma once

#include <string>
#include "json/value.h"

using namespace std;

class ClientMsg {
public:
    static void BuildMsgStr(const string &msgName, const Json::Value &msgData, string &retMsgStr);

    virtual void ToJsonStr(string &retJsonStr) const = 0;

    virtual ~ClientMsg() = default;
};