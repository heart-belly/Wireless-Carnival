#include "client_ban_msg.h"
#include "json_name.h"

void ClientBanMsg::ToJsonStr(string &retJsonStr) const
{
    Json::Value msgData;

    msgData[JsonName::playerId] = playerId;
    msgData[JsonName::hero] = hero;

    ClientMsg::BuildMsgStr(JsonName::client_ban, msgData, retJsonStr);
}
