#pragma once

#include "client_msg.h"

class ReadyMsg : public ClientMsg {
public:
    int playerId;

    void ToJsonStr(string &retJsonStr) const override;
};