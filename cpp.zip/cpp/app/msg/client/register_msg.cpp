#include "register_msg.h"
#include "json_name.h"

void RegisterMsg::ToJsonStr(string &retJsonStr) const
{
    Json::Value msgData;

    msgData[JsonName::playerId] = playerId;
    msgData[JsonName::playerName] = name;
    msgData[JsonName::version] = version;

    BuildMsgStr(JsonName::registration, msgData, retJsonStr);
}
