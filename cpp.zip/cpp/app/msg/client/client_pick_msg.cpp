#include "client_pick_msg.h"
#include "json_name.h"

void ClientPickMsg::ToJsonStr(string &retJsonStr) const
{
    Json::Value msgData;

    msgData[JsonName::playerId] = playerId;
    for (int i = 0; i < heroes.size(); i++) {
        msgData[JsonName ::hero][i] = heroes[i];
    }
    msgData[JsonName::aiTarget] = aiTarget;
    for (int i = 0; i <aiPrompt.size(); i++) {
        msgData[JsonName::aiPrompt][i] = aiPrompt[i];
    }

    ClientMsg::BuildMsgStr(JsonName::client_pick, msgData, retJsonStr);
}
