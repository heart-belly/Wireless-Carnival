#pragma once

#include "json_type.h"
#include "client_msg.h"

class ActionMsg : public ClientMsg {
public:
    int round;
    int playerId;
    vector<HeroAction> heroActionList;

    void ToJsonStr(string &retJsonStr) const override;
};