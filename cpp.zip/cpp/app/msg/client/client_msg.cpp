#include "client_msg.h"
#include "json_name.h"
#include "json/writer.h"

void ClientMsg::BuildMsgStr(const string& msgName, const Json::Value &msgData, string &retMsgStr)
{
    Json::Value root;

    root[JsonName::msg_name] = msgName;
    root[JsonName::msg_data] = msgData;

    Json::FastWriter writer;
    retMsgStr = writer.write(root);
    char lenBuf[10];
    snprintf(lenBuf, sizeof(lenBuf), "%05d", (int)retMsgStr.length());
    retMsgStr = lenBuf + retMsgStr;
}
