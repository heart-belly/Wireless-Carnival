#pragma once

#include "client_msg.h"
class ClientBanMsg : public ClientMsg  {
public:
    int playerId;
    int hero;

    void ToJsonStr(string &retJsonStr) const override;
};