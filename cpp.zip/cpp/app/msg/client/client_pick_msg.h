#pragma once

#include <vector>
#include "client_msg.h"

class ClientPickMsg : public ClientMsg {
public:
    int playerId;
    vector<int> heroes;
    int aiTarget;
    vector<string> aiPrompt;

    void ToJsonStr(string &retJsonStr) const override;
};