#pragma once

#include "client_msg.h"

class RegisterMsg  : public ClientMsg {
public:
    int playerId;
    string name;
    string version;

    void ToJsonStr(string &retJsonStr) const override;
};