#pragma once

#include "server_msg.h"
#include "json/value.h"
#include "json_type.h"
#include "socket_connect.h"

class GameStartMsg : public ServerMsg {
public:
    GameInitialInfo initialInfo_;
    explicit GameStartMsg(Json::Value);
    int Process(SocketConnect &socketConnect) const override;
};
