#include "msg_data_parser.h"
#include "utils.h"

bool MsgDataParser::GetMember(Json::Value &val, const string& key, Json::Value &objVal)
{
    if (!val.isMember(key) || !val[key].isObject()) {
        return false;
    }
    objVal = val[key];
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, int &intVal)
{
    if (!val.isMember(key) || !val[key].isInt()) {
        return false;
    }
    intVal = val[key].asInt();
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, string &strVal)
{
    // Log("GetMember string");
    if (!val.isMember(key) || !val[key].isString()) {
        // Log("4357 GetMember fail");
        return false;
    }
    strVal = val[key].asString();
    // Log("GetMember string succ");
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, bool &boolVal)
{
    if (val.isMember(key)) {
        if (val[key].isBool()) {
            boolVal = val[key].asBool();
            return true;
        } else if (val[key].isString()) {
            string oo = val[key].asString();
            if (oo == "False") {
                boolVal = false;
                return true;
            } else if (oo == "True") {
                boolVal = true;
                return true;
            }
        }
    }
    return false;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<int> &vectorVale)
{
    if (!val.isMember(key)) {
        return false;
    }
    Json::Value &tmp = val[key];

    // 对于字符串构成的int数组，特殊处理
    if (tmp.isString()) {
        string xx = tmp.asString();
        auto ss = split(xx, ',');
        for (const string& a : ss) {
            vectorVale.push_back(std::stoi(a));
        }
        return true;
    }

    if (!val[key].isArray()) {
        return false;
    }
    for (const auto & i : tmp) {
        if (!i.isInt()) {
            return false;
        }
        vectorVale.push_back(i.asInt());
    }
    return true;
}

static bool GetPos(Json::Value &val, Pos &pos)
{
    if (!val.isArray() || val.empty()) {
        return false;
    }

    CHECK_RET(val[0].isInt());
    pos.x_ = val[0].asInt();
    CHECK_RET(val[1].isInt());
    pos.y_ = val[1].asInt();
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, Pos &pos)
{
    if (!val.isMember(key)) {
        return false;
    }

    return GetPos(val[key], pos);
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<Pos> &poses)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }

    for (auto &value : val[key]) {
        Pos pos{};
        if (!GetPos(value, pos)) {
            return false;
        }
        poses.push_back(pos);
    }
    return true;
}

static void GetTowerDetail(Json::Value &cur, TowerDetail &towerDetail)
{
    GET_MEMBER_ERROR_RETURN(cur, JsonName::pos, towerDetail.poses);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::HP, towerDetail.hp);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::maxHP, towerDetail.maxHp);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::atk, towerDetail.atk);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::atkDis, towerDetail.atkDis);

    GET_MEMBER_OPTIONAL(cur, JsonName::id, towerDetail.id);
    GET_MEMBER_OPTIONAL(cur, JsonName::hateId, towerDetail.hateId);
    GET_MEMBER_OPTIONAL(cur, JsonName::action, towerDetail.action);
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<TowerDetail> &towerDetails)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }

    for (auto &cur : val[key]) {
        TowerDetail towerDetail;
        GetTowerDetail(cur, towerDetail);
        towerDetails.push_back(towerDetail);
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<Tower> &towers)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }
    for (auto &cur : val[key]) {
        Tower tower;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::playerId, tower.playerId);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::detail, tower.details);
        towers.push_back(tower);
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<Base> &bases)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }

    for (int i = 0; i < val[key].size(); i++) {
        Base base;
        Json::Value &cur = val[key][i];
        GET_MEMBER_ERROR_RETURN(cur, JsonName::playerId, base.playerId);
        if (!cur.isMember(JsonName::detail)) {
            return false;
        }
        GetTowerDetail(cur[JsonName::detail], base.detail);
        bases.push_back(base);
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, Rune &rune)
{
    if (!val.isMember(key)) {
        return false;
    }

    Json::Value &cur = val[key];
    if (cur.empty()) {
        PRINT_INFO("no rune info");
        rune.isValid = false;
        return true;
    }
    rune.isValid = true;
    GET_MEMBER_ERROR_RETURN(cur, JsonName::id, rune.id);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::pos, rune.pos);
    int runeType = 0;
    GET_MEMBER_ERROR_RETURN(cur, JsonName::type, runeType);
    rune.type = (RuneType)runeType;
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, RunesInitial &rune)
{
    if (!val.isMember(key)) {
        return false;
    }

    Json::Value &cur = val[key];
    GET_MEMBER_ERROR_RETURN(cur, JsonName::bornRound, rune.bornRound);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::pos, rune.pos);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::refreshPeriod, rune.refreshPeriod);
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<Equipment> &equipments)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }

    for (auto & cur : val[key]) {
        Equipment equipment = {INVALID_EQUIP, 0, 0, 0};
        GET_MEMBER_ERROR_RETURN(cur, JsonName::price, equipment.price);
        int equipType;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::type, equipType);
        equipment.type = (EquipType)equipType;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::cd, equipment.cd);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::duration, equipment.duration);
        equipments.push_back(equipment);
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<EquipmentOfHero> &equipments)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }

    for (auto & cur : val[key]) {
        EquipmentOfHero equipment;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::cdRemain, equipment.cdRemain);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::type, equipment.type);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::cd, equipment.cd);
        equipments.push_back(equipment);
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, Shop &shop)
{
    if (!val.isMember(key)) {
        return false;
    }

    Json::Value &cur = val[key];
    GET_MEMBER_ERROR_RETURN(cur, JsonName::pos, shop.poses);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::equipments, shop.equipments);
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, StaticMap &map)
{
    if (!val.isMember(key)) {
        return false;
    }

    Json::Value &cur = val[key];
    GET_MEMBER_ERROR_RETURN(cur, JsonName::maxX, map.maxX);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::maxY, map.maxY);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::data, map.data);
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<Grass> &grasses)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }

    for (auto & cur : val[key]) {
        Grass grass;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::pos, grass.poses);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::id, grass.id);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::type, grass.type);
        grasses.push_back(grass);
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, Buildings &buildings)
{
    if (!val.isMember(key)) {
        return false;
    }

    Json::Value &cur = val[key];
    GET_MEMBER_ERROR_RETURN(cur, JsonName::tower, buildings.towers);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::base, buildings.bases);

    GET_MEMBER_OPTIONAL(cur, JsonName::shop, buildings.shop);
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, int array[], int arrayLen)
{
    if (!val.isMember(key) || !val.isArray() || val.size() != arrayLen) {
        return false;
    }

    Json::Value &cur = val[key];
    for (int i = 0; i < arrayLen; i++) {
        array[i] = cur[i].asInt();
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, Action &action)
{
    if (!val.isMember(key)) {
        return false;
    }

    Json::Value &cur = val[key];

    int tmp = 0;
    GET_MEMBER_OPTIONAL(cur, JsonName::type, tmp);
    action.type = (ActionType)tmp;

    GET_MEMBER_OPTIONAL(cur, JsonName::EquipId, tmp);
    action.useEquipId = (EquipType)tmp;

    GET_MEMBER_OPTIONAL(cur, JsonName::skillId, action.skillId);
    GET_MEMBER_OPTIONAL(cur, JsonName::targetPos, action.targetPos);
    vector<int> equips;
    GET_MEMBER_OPTIONAL(cur, JsonName::targetId, equips);
    action.buyEquipIds.clear();
    for (int equip : equips) {
        action.buyEquipIds.push_back((EquipType)equip);
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value& val, const string& key, ActionOfTower& action)
{
    if (!val.isMember(key)) {
        return false;
    }

    Json::Value &cur = val[key];

    int tmp;
    GET_MEMBER_OPTIONAL(cur, JsonName::type, tmp);
    action.type = (ActionType)tmp;
    GET_MEMBER_OPTIONAL(cur, JsonName::targetPos, action.target);
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, Status &status)
{
    if (!val.isMember(key)) {
        return false;
    }

    Json::Value &cur = val[key];
    GET_MEMBER_ERROR_RETURN(cur, JsonName::debuffImmu, status.debuffImmu);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::dizzy, status.dizzy);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::phyDamageImmu, status.phyDamageImmu);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::magicDamageImmu, status.magicDamageImmu);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::cantMove, status.cantMove);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::cantAttack, status.cantAttack);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::doubleAttack, status.doubleAttack);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::halfAttack, status.halfAttack);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::targeted, status.targeted);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::teleporting, status.teleporting);

    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<Skill> &skills)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }

    for (auto & cur : val[key]) {
        Skill skill;
        int tmp;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::id, tmp);
        skill.skillId = (SkillId)tmp;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::cd, skill.cd);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::duration, skill.duration);

        GET_MEMBER_OPTIONAL(cur, JsonName::cdRemainRound, skill.cdRemainRound);
        GET_MEMBER_OPTIONAL(cur, JsonName::durationRemainRound, skill.durationRemainRound);
        GET_MEMBER_OPTIONAL(cur, JsonName::attackRange, skill.attackRange);
        GET_MEMBER_OPTIONAL(cur, JsonName::attackCenter, skill.attackCenter);
        skills.push_back(skill);
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<HeroInfo> & heroesInfo)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }

    for (auto & cur : val[key]) {
        HeroInfo heroInfo;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::playerId, heroInfo.playerId);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::id, heroInfo.heroId);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::pos, heroInfo.pos);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::HP, heroInfo.hp);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::maxHP, heroInfo.maxHp);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::atk, heroInfo.atk);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::atkDis, heroInfo.atkDis);
        int tmp;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::type, tmp);
        heroInfo.heroType = (HeroType)tmp;

        GET_MEMBER_OPTIONAL(cur, JsonName::skills, heroInfo.skills);
        GET_MEMBER_OPTIONAL(cur, JsonName::dead, heroInfo.isDead);
        GET_MEMBER_OPTIONAL(cur, JsonName::bornPos, heroInfo.bornPos);
        GET_MEMBER_OPTIONAL(cur, JsonName::isSeen, heroInfo.isSeen);
        GET_MEMBER_OPTIONAL(cur, JsonName::reviveRound, heroInfo.reviveRound);
        GET_MEMBER_OPTIONAL(cur, JsonName::money, heroInfo.money);
        GET_MEMBER_OPTIONAL(cur, JsonName::rewardMoney, heroInfo.rewardMoney);
        GET_MEMBER_OPTIONAL(cur, JsonName::equipment, heroInfo.equipments);
        GET_MEMBER_OPTIONAL(cur, JsonName::action, heroInfo.action);
        GET_MEMBER_OPTIONAL(cur, JsonName::status, heroInfo.status);
        heroesInfo.push_back(heroInfo);
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<Player> &players)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }

    for (auto & cur : val[key]) {
        Player player;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::playerId, player.playerId);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::name, player.name);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::herosInfo, player.heroesInfo);
        players.push_back(player);
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<SoldierDetail> &details)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }

    for (auto & cur : val[key]) {
        SoldierDetail detail;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::id, detail.id);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::pos, detail.pos);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::HP, detail.hp);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::maxHP, detail.maxHP);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::type, detail.type);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::hateId, detail.hateId);
        Json::Value status = cur[JsonName::status];
        GET_MEMBER_ERROR_RETURN(status, JsonName::cantMove, detail.status.cantMove);
        GET_MEMBER_ERROR_RETURN(status, JsonName::cantAttack, detail.status.cantAttack);
        GET_MEMBER_ERROR_RETURN(status, JsonName::dizzy, detail.status.dizzy);
        GET_MEMBER_ERROR_RETURN(status, JsonName::magicDamageImmu, detail.status.magicDamageImmu);
        GET_MEMBER_ERROR_RETURN(status, JsonName::phyDamageImmu, detail.status.phyDamageImmu);
        details.push_back(detail);
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<Soldier> &soldiers)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }

    for (auto & cur : val[key]) {
        Soldier soldier;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::playerId, soldier.playerId);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::detail, soldier.details);

        soldiers.push_back(soldier);
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, VictoryCamp &victoryCamp)
{
    if (!val.isMember(key)) {
        return false;
    }

    Json::Value &cur = val[key];
    GET_MEMBER_ERROR_RETURN(cur, JsonName::playerId, victoryCamp.playerId);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::name, victoryCamp.name);
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<CampInfo> &campsInfo)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }

    for (auto & cur : val[key]) {
        CampInfo campInfo;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::playerId, campInfo.playerId);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::name, campInfo.name);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::money, campInfo.money);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::killNum, campInfo.killNum);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::killTower, campInfo.killTower);
        campsInfo.push_back(campInfo);
    }
    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, Monster &monster)
{
    if (!val.isMember(key)) {
        return false;
    }

    Json::Value &cur = val[key];
    if (cur.empty()) {
        PRINT_INFO("no rune info");
        monster.isValid = false;
        return true;
    }

    monster.isValid = true;
    GET_MEMBER_ERROR_RETURN(cur, JsonName::maxHP, monster.maxHp);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::HP, monster.hp);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::atk, monster.atk);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::atkDis, monster.atkDis);
    GET_MEMBER_ERROR_RETURN(cur, JsonName::pos, monster.pos);

    GET_MEMBER_OPTIONAL(cur, JsonName::id, monster.id);
    GET_MEMBER_OPTIONAL(cur, JsonName::bornPos, monster.bornPos);
    GET_MEMBER_OPTIONAL(cur, JsonName::bornRound, monster.bornRound);
    GET_MEMBER_OPTIONAL(cur, JsonName::refreshPeriod, monster.refreshPeriod);
    GET_MEMBER_OPTIONAL(cur, JsonName::action, monster.action);
    GET_MEMBER_OPTIONAL(cur, JsonName::sleeping, monster.sleeping);
    GET_MEMBER_OPTIONAL(cur, JsonName::hateId, monster.hateId);

    return true;
}

bool MsgDataParser::GetMember(Json::Value &val, const string& key, vector<SoldierInitial> &soldierList)
{
    if (!val.isMember(key) || !val[key].isArray()) {
        return false;
    }

    for (auto & cur : val[key]) {
        SoldierInitial soldierInitial;
        GET_MEMBER_ERROR_RETURN(cur, JsonName::playerId, soldierInitial.playerId);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::bornPos, soldierInitial.bornPos);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::bornRound, soldierInitial.bornRound);
        GET_MEMBER_ERROR_RETURN(cur, JsonName::refreshPeriod, soldierInitial.refreshPeriod);
        soldierList.push_back(soldierInitial);
    }
    return true;
}
