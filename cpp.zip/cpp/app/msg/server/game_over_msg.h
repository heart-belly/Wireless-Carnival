#pragma once

#include "json/value.h"
#include "json_type.h"
#include "server_msg.h"
#include "socket_connect.h"

class GameOverMsg : public ServerMsg{
public:
    GameOverMsg(Json::Value);

    vector<HeroInfo> heroInfoList;
    vector<CampInfo> campInfos;
    VictoryCamp victoryCamp;
    int round;

    int Process(SocketConnect &socketConnect) const override;
};
