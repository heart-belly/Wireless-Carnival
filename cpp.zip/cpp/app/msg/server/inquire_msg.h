#pragma once

#include "json/value.h"
#include "json_type.h"
#include "server_msg.h"
#include "socket_connect.h"
#include "action_msg.h"

class InquireMsg : public ServerMsg {
public:
    explicit InquireMsg(Json::Value);

    int Process(SocketConnect &socketConnect) const override;

    GameRoundInfo roundInfo_;
};
