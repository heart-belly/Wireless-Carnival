#include "inquire_msg.h"
#include "json_name.h"
#include "msg_data_parser.h"
#include "game_context.h"
#include "team_ai.h"

int InquireMsg::Process(SocketConnect& socketConnect) const
{
    GameContext& ins = GameContext::Instance();

    // 更新本轮游戏的数据
    ins.UpdateByInquireMsg(roundInfo_);

    ActionMsg actionMsg;
    int ownPlayerId = ins.GetOwnPlayerId();
    actionMsg.playerId = ownPlayerId;
    actionMsg.round = ins.GetRound();
    TeamAi::DecideTeamAction(actionMsg.heroActionList);

    socketConnect.SendMsg(actionMsg);
    return 0;
}

InquireMsg::InquireMsg(Json::Value rootVal)
{
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::round, roundInfo_.round);
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::herosInfo, roundInfo_.heroesInfo);
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::buildings, roundInfo_.buildings);
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::soldier, roundInfo_.soldiers);
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::campInfo, roundInfo_.campsInfo);
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::runes, roundInfo_.runes);
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::monster, roundInfo_.monster);
}
