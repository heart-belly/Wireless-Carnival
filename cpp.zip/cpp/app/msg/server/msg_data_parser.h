#pragma once

#include <iostream>
#include "json_type.h"
#include "log.h"
#include "json_name.h"
#include "json/value.h"

#define THROW_LOGIC_ERROR_WITH_CONTEXT(msg)                                                                           \
    Json::throwLogicError((msg) + std::string(" Function: ") + __FUNCTION__ + ", Line: " + std::to_string(__LINE__) + \
                          "]")

#define CHECK_RET(ret)                                   \
    do {                                                 \
        if (!ret) {                                      \
            THROW_LOGIC_ERROR_WITH_CONTEXT("CHECK_RET"); \
        }                                                \
    } while (0)

#define GET_MEMBER_ERROR_RETURN(objVal, name, val)                             \
    do {                                                                       \
        if (!MsgDataParser::GetMember(objVal, name, val)) {                    \
            THROW_LOGIC_ERROR_WITH_CONTEXT("GET_MEMBER_ERROR_RETURN " + name); \
        }                                                                      \
    } while (0)

#define GET_MEMBER_OPTIONAL(objVal, name, val)             \
    do {                                                   \
        if (MsgDataParser::GetMember(objVal, name, val)) { \
            ;                                              \
        }                                                  \
    } while (0)

class MsgDataParser {
public:
    static bool GetMember(Json::Value& val, const string& key, int& intVal);
    static bool GetMember(Json::Value& val, const string& key, Json::Value& objVal);
    static bool GetMember(Json::Value& val, const string& key, string& strVal);
    static bool GetMember(Json::Value& val, const string& key, bool& boolVal);
    static bool GetMember(Json::Value& val, const string& key, vector<int>& vectorVale);
    static bool GetMember(Json::Value& val, const string& key, Pos& pos);
    static bool GetMember(Json::Value& val, const string& key, vector<Pos>& poses);
    static bool GetMember(Json::Value& val, const string& key, vector<TowerDetail>& towerDetails);
    static bool GetMember(Json::Value& val, const string& key, vector<Tower>& towers);
    static bool GetMember(Json::Value& val, const string& key, vector<Base>& bases);
    static bool GetMember(Json::Value& val, const string& key, Rune& rune);
    static bool GetMember(Json::Value& val, const string& key, vector<Equipment>& equipments);
    static bool GetMember(Json::Value& val, const string& key, vector<EquipmentOfHero>& equipments);
    static bool GetMember(Json::Value& val, const string& key, Shop& shop);
    static bool GetMember(Json::Value& val, const string& key, StaticMap& map);
    static bool GetMember(Json::Value& val, const string& key, vector<Grass>& grasses);
    static bool GetMember(Json::Value& val, const string& key, Buildings& buildings);
    static bool GetMember(Json::Value& val, const string& key, int* array, int arrayLen);
    static bool GetMember(Json::Value& val, const string& key, Action& action);
    static bool GetMember(Json::Value& val, const string& key, ActionOfTower& action);
    static bool GetMember(Json::Value& val, const string& key, Status& status);
    static bool GetMember(Json::Value& val, const string& key, vector<Skill>& skills);
    static bool GetMember(Json::Value& val, const string& key, vector<HeroInfo>& heroesInfo);
    static bool GetMember(Json::Value& val, const string& key, vector<Player>& players);
    static bool GetMember(Json::Value& val, const string& key, vector<SoldierDetail>& details);
    static bool GetMember(Json::Value& val, const string& key, vector<Soldier>& soldiers);
    static bool GetMember(Json::Value& val, const string& key, VictoryCamp& victoryCamp);
    static bool GetMember(Json::Value& val, const string& key, vector<CampInfo>& campsInfo);
    static bool GetMember(Json::Value& val, const string& key, Monster& monster);
    static bool GetMember(Json::Value& val, const string& key, RunesInitial& rune);
    static bool GetMember(Json::Value& val, const string& key, vector<SoldierInitial>& soldierList);
};
