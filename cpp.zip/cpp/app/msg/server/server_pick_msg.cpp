#include "server_pick_msg.h"
#include "json_name.h"
#include "msg_data_parser.h"
#include "game_context.h"
#include "client_pick_msg.h"
#include "game_config.h"

ServerPickMsg::ServerPickMsg(Json::Value rootVal)
{
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::hero, heroes_);
}

int ServerPickMsg::Process(SocketConnect& socketConnect) const
{
    GameContext& ins = GameContext::Instance();
    ClientPickMsg clientPickMsg;
    vector<HeroType> frontHeroList = {CRYSTAL_MAIDEN, TREANT_PROTECTOR};
    vector<HeroType> backHeroList = {LINA, HUSKAR};

    HeroType frontHero;
    HeroType backHero;
    PRINT_INFO("当前id %d", ins.GetOwnPlayerId());
    if (ins.GetOwnPlayerId() == 1111) {
        frontHero = g_clientHero1;
        backHero = g_clientHero2;
    } else {
        frontHero = SelectHero(frontHeroList);
        backHero = SelectHero(backHeroList);
    }

    clientPickMsg.playerId = ins.GetOwnPlayerId();
    HeroType myHeroesType[] = {frontHero, backHero};
    clientPickMsg.aiTarget = myHeroesType[0];  // 附身第一个英雄


    // Ai伙伴附身到哪个英雄的策略
    string aiPrompt1 = "请基于如下策略进行输出：-输出我方血量最高的英雄的ID，格式[ID:xxxx]。不要输出其他信息。";
    clientPickMsg.aiPrompt.push_back(aiPrompt1);

    // Ai伙伴释放技能的策略
    string aiPrompt2 = string("请基于如下策略进行输出：\n") + "-找到我附身的友方英雄的信息；\n"
                       + "-如果附近敌方英雄为空，不使用技能；否则，如果如果字段'当前状态'包含'眩晕'或者'禁锢'，使用技能3；否则，使用技能2；\n"
                       + "-逐步考虑问题，但减少过程输出。\n" + "-输出格式为[SkillID:X]，X为技能ID，取值0-3，0代表不使用技能。\n"
                       + "样例1：\n" + "输出：找到当前附身英雄为1001，但'附近敌方英雄信息'为空，所以不使用技能。返回[SkillID:0]\n"
                       + "样例2：\n" + "输出：找到当前附身英雄为1001，'附近敌方英雄信息'不为空，且'当前状态'列表包含'眩晕'，所以使用技能3。返回[SkillID:3]\n"
                       + "样例3：\n" + "输出：找到当前附身英雄为1002，'附近敌方英雄信息'不为空，且'当前状态'不包含'禁锢'或者'眩晕'，所以使用技能2。返回[SkillID:2]\n";
    clientPickMsg.aiPrompt.push_back(aiPrompt2);


    // 根据选择创建具体的Hero
    for (HeroType curHeroType : myHeroesType) {
        clientPickMsg.heroes.push_back(curHeroType);
    }

    socketConnect.SendMsg(clientPickMsg);
    return 0;
}

HeroType ServerPickMsg::SelectHero(vector<HeroType>& heroList) const
{
    for (auto myHero : heroList) {
        for (auto serverHero : heroes_) {
            if (myHero == serverHero) {
                PRINT_INFO("找到了想要的英雄，选它!");
                return myHero;
            }
        }
    }
    return heroList[0];
}
