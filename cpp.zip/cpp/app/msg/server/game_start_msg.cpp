#include "game_start_msg.h"
#include "msg_data_parser.h"
#include "game_context.h"
#include "ready_msg.h"

GameStartMsg::GameStartMsg(Json::Value rootVal)
{
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::map, initialInfo_.map);
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::herosInfo, initialInfo_.heroesInfo);
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::buildings, initialInfo_.buildings);
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::soldier, initialInfo_.soldierList);
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::monster, initialInfo_.monster);
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::monster, initialInfo_.runes);
}

int GameStartMsg::Process(SocketConnect &socketConnect) const
{
    GameContext &ins = GameContext::Instance();
    ins.UpdateByStartMsg(initialInfo_);

    ReadyMsg readyMsg;
    readyMsg.playerId = ins.GetOwnPlayerId();
    socketConnect.SendMsg(readyMsg);
    return 0;
}
