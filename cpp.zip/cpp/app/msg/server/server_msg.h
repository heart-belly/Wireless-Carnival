#pragma once

#include <memory>
#include "socket_connect.h"

class ServerMsg {
public:
    // 处理当前服务器发送来的消息，0：继续消息处理 其他：消息处理结束
    virtual int Process(SocketConnect &socketConnect) const = 0;

    virtual ~ServerMsg() = default;

    // 从json字符串解析出具体的服务器消息
    static unique_ptr<ServerMsg> Parse(const char* jsonStr);
};
