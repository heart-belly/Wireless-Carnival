#pragma once

#include "json/value.h"
#include "server_msg.h"
#include "socket_connect.h"
#include "json_type.h"

class ServerPickMsg : public ServerMsg {
public:
    explicit ServerPickMsg(Json::Value);

    std::vector<int> heroes_;

    int Process(SocketConnect &socketConnect) const override;
    HeroType SelectHero(vector<HeroType>& heroList) const;
};
