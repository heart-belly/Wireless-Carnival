#include <cstring>
#include <memory>
#include "server_msg.h"
#include "json/reader.h"
#include "log.h"
#include "msg_data_parser.h"
#include "game_start_msg.h"
#include "server_pick_msg.h"
#include "inquire_msg.h"
#include "game_over_msg.h"
#include "server_ban_msg.h"

unique_ptr<ServerMsg> ServerMsg::Parse(const char *jsonStr)
{
    Json::Value rootVal;
    Json::Reader reader;
    Json::Value msgData;

    if (!reader.parse(jsonStr, jsonStr + strlen(jsonStr), rootVal)) {
        PRINT_ERROR("reader.parse fail: %s", jsonStr);
        return nullptr;
    }

    string stringVal;
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::msg_data, msgData);
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::msg_name, stringVal);
    if (stringVal == JsonName::gameStart) {
        return std::make_unique<GameStartMsg>(msgData);
    } else if (stringVal == JsonName::server_pick) {
        return std::make_unique<ServerPickMsg>(msgData);
    } else if (stringVal == JsonName::inquire) {
        return std::make_unique<InquireMsg>(msgData);
    } else if (stringVal == JsonName::over) {
        return std::make_unique<GameOverMsg>(msgData);
    } else if (stringVal == JsonName::server_ban) {
        return std::make_unique<ServerBanMsg>(msgData);
    }
    return nullptr;
}
