#include "server_ban_msg.h"
#include "client_ban_msg.h"
#include "game_context.h"

int ServerBanMsg::Process(SocketConnect& socketConnect) const
{
    GameContext ins = GameContext::Instance();
    ClientBanMsg clientBanMsg;

    clientBanMsg.playerId = ins.GetOwnPlayerId();
    clientBanMsg.hero = PUDGE;
    socketConnect.SendMsg(clientBanMsg);
    return 0;
}

ServerBanMsg::ServerBanMsg(Json::Value value) {
    // TODO 暂时无脑ban英雄，不看server的消息
}
