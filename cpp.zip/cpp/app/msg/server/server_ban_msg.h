#pragma once

#include "server_msg.h"
#include "json_type.h"

struct LastMatchInfo {

};

class ServerBanMsg : public ServerMsg {
public:
    explicit ServerBanMsg(Json::Value value);
    int Process(SocketConnect& socketConnect) const override;

private:
    vector<HeroType> heroList_;
    vector<LastMatchInfo> lastMatchInfoList_;
};
