#include "game_over_msg.h"
#include "json_name.h"
#include "msg_data_parser.h"

GameOverMsg::GameOverMsg(Json::Value rootVal)
{
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::campInfo, campInfos);
    GET_MEMBER_ERROR_RETURN(rootVal, JsonName::round, round);
}

int GameOverMsg::Process(SocketConnect&) const
{
    PRINT_INFO("Game over! The winner is: %d %s", victoryCamp.playerId, victoryCamp.name.c_str());
    return 1;
}
