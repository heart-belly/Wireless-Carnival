#ifndef LOG_H
#define LOG_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    LEVEL_DEBUG = 0,  // 调试信息
    LEVEL_INFO,       // 一般信息
    LEVEL_WARN,       // 警告信息
    LEVEL_ERROR,      // 错误信息
} LogLevel;

extern void LOG_Print(LogLevel level, const char* file, const char* func, const char* fmt, ...)
    __attribute__((format(printf, 4, 5)));

#define INNER_PRINT(level, format, args...)                          \
    do {                                                             \
        LOG_Print(level, __FILE__, __func__, format "\n", ##args); \
    } while (0)

#define PRINT_DEBUG(format, args...) INNER_PRINT(LEVEL_DEBUG, format, ##args)
#define PRINT_INFO(format, args...) INNER_PRINT(LEVEL_INFO, format, ##args)
#define PRINT_WARN(format, args...) INNER_PRINT(LEVEL_WARN, format, ##args)
#define PRINT_ERROR(format, args...) INNER_PRINT(LEVEL_ERROR, format, ##args)

void Pause();
void LOG_Init(int playerId);

#ifdef __cplusplus
}
#endif

#endif /* LOG_H */