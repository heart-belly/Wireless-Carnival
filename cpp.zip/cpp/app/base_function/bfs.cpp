#include <queue>
#include <vector>
#include <unordered_map>
#include <algorithm>  // std::reverse
#include "pos.h"
#include "bfs.h"
#include "map.h"


typedef pair<int, int> PII;
typedef pair<int, pair<int, int>> PIP;
// 定义 Pos 的哈希函数
struct PointHash {
    std::size_t operator()(const Pos &p) const
    {
        return std::hash<int>()(p.x_) ^ std::hash<int>()(p.y_);
    }
};

// 检查点是否在网格范围内
bool IsValid(const Pos &point, int rows, int cols)
{
    return point.y_ >= 0 && point.y_ < rows && point.x_ >= 0 && point.x_ < cols;
}

// 重建路径
std::vector<Pos> ReconstructPath(std::unordered_map<Pos, Pos, PointHash> &cameFrom, Pos start, Pos end)
{
    std::vector<Pos> path;
    Pos current = end;
    while (!(current == start)) {
        path.push_back(current);
        current = cameFrom[current];
    }
    path.push_back(start);                   // 添加起点
    std::reverse(path.begin(), path.end());  // 反转路径，使起点在前，终点在后
    return path;
}

// 执行 BFS 搜索路径，目标点默认可达
std::vector<Pos> BFS_FindPath(const std::vector<std::vector<int> > &grid, const Pos &start, const Pos &end)
{
    int rows = grid.size();
    int cols = grid[0].size();
    std::queue<Pos> queue;
    std::unordered_map<Pos, Pos, PointHash> cameFrom;

    // 8 个方向：上下左右及四个对角线方向
    std::vector<Pos> directions = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};

    queue.push(start);
    cameFrom[start] = start;

    while (!queue.empty()) {
        Pos current = queue.front();
        queue.pop();

        if (current == end) {
            return ReconstructPath(cameFrom, start, end);
        }

        for (const auto &dir : directions) {
            Pos neighbor = {current.x_ + dir.x_, current.y_ + dir.y_};

            if (IsValid(neighbor, rows, cols) && (Map::IsReachable((MapPosType)grid[neighbor.y_][neighbor.x_]) || neighbor == end)
                && cameFrom.find(neighbor) == cameFrom.end()) {
                queue.push(neighbor);
                cameFrom[neighbor] = current;
            }
        }
    }

    return {};  // 没有找到路径
}

// 执行 BFS 搜索路径，目标点默认可达
std::vector<Pos> aStar_FindPath(const std::vector<std::vector<int> > &grid, const Pos &start, const Pos &end) {
    // 估计距离函数
    auto f = [&](auto&&, int x, int y, int ex, int ey) {
        return abs(x - ex) + abs (y - ey);
    };

    int rows = grid.size();
    int cols = grid[0].size();
    std::priority_queue<PIP, vector<PIP>, greater<PIP>> heap;

    int maxRC = max(rows, cols);
    vector<vector<int>> dist(maxRC, vector<int>(maxRC, -1));

    std::unordered_map<Pos, Pos, PointHash> cameFrom;

    // 8 个方向：上下左右及四个对角线方向
    std::vector<Pos> directions = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};


    dist[start.x_][start.y_] = 0;
    heap.push({0 + f(f, start.x_, start.y_, end.x_, end.y_), {start.x_, start.y_}});
    cameFrom[start] = start;

    while (heap.size()) {
        int distance = heap.top().first;
        PII pos = heap.top().second;
        heap.pop();

        if (Pos{pos.first, pos.second} == end) {
            return ReconstructPath(cameFrom, start, end);
        }
        for (const auto &dir : directions) {
            Pos neighbor = {pos.first + dir.x_, pos.second + dir.y_};

            if (IsValid(neighbor, rows, cols) && (Map::IsReachable((MapPosType)grid[neighbor.y_][neighbor.x_]) || neighbor == end)
                && cameFrom.find(neighbor) == cameFrom.end()) {
                dist[neighbor.x_][neighbor.y_] = dist[pos.first][pos.second] + 1;
                heap.push({dist[neighbor.x_][neighbor.y_] + f(f, neighbor.x_, neighbor.y_, end.x_, end.y_), {neighbor.x_, neighbor.y_}});
                cameFrom[neighbor] = Pos{pos.first, pos.second};
            }
        }
    }
    return {};  // 没有找到路径
}

// 获取从 start 到 end 的路径上的下一步移动
bool BFS_GetNextMove(const std::vector<std::vector<int> > &grid, const Pos &start, const Pos &end, Pos &next)
{
    int length;
    return BFS_GetNextMove(grid, start, end, next, length);
}

// 获取从 start 到 end 的路径上的下一步移动
bool BFS_GetNextMove(const std::vector<std::vector<int> > &grid, const Pos &start, const Pos &end, Pos &next, int &length)
{
    bool ret;

    std::vector<Pos> path = aStar_FindPath(grid, start, end);
    if (path.size() < 2) {
        ret = false;  // 没有路径或路径只有起点
        next = {-1, -1};
        length = -1;
    } else {
        ret = true;
        next = path[1];  // 返回路径上的下一步
        length = path.size();
    }
    return ret;
}

int BFS_GetDistance(const std::vector<std::vector<int> > &grid, const Pos &start, const Pos &end)
{
    std::vector<Pos> path = aStar_FindPath(grid, start, end);
    return path.size();
}
