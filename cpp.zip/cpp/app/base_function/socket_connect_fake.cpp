#include "socket_connect_fake.h"
#include "game_context.h"
#include "game_config.h"
#include <utility>
#include <iostream>
#include "string.h"

int SocketConnectFake::Connect(const string&, unsigned short)
{
    fileStream_.open(replayFileName_);
    if (!fileStream_.is_open()) {
        PRINT_ERROR("Failed to open file: %s", replayFileName_.c_str());
        return -1;
    }
    return 0;
}

int SocketConnectFake::Disconnect()
{
    fileStream_.close();
    return 0;
}

int SocketConnectFake::SendMsg(const ClientMsg&) const
{
    PRINT_INFO("send client msg");
    return 1;
}

void SocketConnectFake::RecvMsg(char* buffer, int msgSize)
{
    static int curRound = 0;

    if (msgSize == MSG_LENTH_NUMBER) {
        const char* lengthMsg = "99999";
        // 跳过获取长度的这次请求，固定返回
        strncpy(buffer, lengthMsg, strlen(lengthMsg));
        return;
    }

    // 如果是快进模式，读取inquire消息的时候，直接跳到对应的轮数
    // 每次调用先跳过一行，然后读取下一行的内容
    std::string line;
    GameContext ins = GameContext::Instance();
    while (true) {
//         if (!std::getline(fileStream_, line)) {
//             // 如果跳过失败（例如到达文件末尾），关闭文件
//             throw runtime_error("无法读取文件");
//         }

        if (!std::getline(fileStream_, line)) {
            // 如果跳过失败（例如到达文件末尾），关闭文件
            throw runtime_error("无法读取文件");
        }

        if (line.find("inquire") != string::npos) {
            curRound++;
        }

        if (curRound == 0) {
            // 还没到inquire消息部分，返回对应的消息
            strncpy(buffer, line.c_str(), msgSize);
            return;
        }

        // 已经到了inquire消息部分
        if (curRound >= g_breakRound) {
            // 已到达设定的轮数
            if (curRound == g_breakRound) {
                PRINT_WARN("到达设定的轮数 %d", curRound);
                Pause();
            }
            strncpy(buffer, line.c_str(), msgSize);
            return;
        }

        if (!g_isStepTo) {
            // 非一步直达模式，返回当前的内容，否则继续循环取下一条消息
            strncpy(buffer, line.c_str(), msgSize);
            return;
        }
    }
}

SocketConnectFake::SocketConnectFake(string replayFile) : replayFileName_(std::move(replayFile)) {}