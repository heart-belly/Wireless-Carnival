#include "utils.h"

std::vector<std::string> split(const std::string &str, const char c)
{
    std::string tmp;
    std::vector<std::string> res;
    for (char i : str) {
        if (i == c && !tmp.empty()) {
            res.push_back(tmp);
            tmp.clear();
            continue;
        }
        tmp.push_back(i);
    }
    if (!tmp.empty()) {
        res.push_back(tmp);
    }
    return res;
}
