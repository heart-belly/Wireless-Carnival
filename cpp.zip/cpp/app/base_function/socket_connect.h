#pragma once

#include "log.h"
#include "client_msg.h"
#ifdef WIN32
#include <WinSock2.h>
#else
#include <sys/socket.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#endif

#ifndef WIN32
typedef int SOCKET;
typedef unsigned char BYTE;
typedef unsigned long DWORD;
#define FALSE 0
#define SOCKET_ERROR (-1)
#endif

#ifdef WIN32
#include <windows.h>
#define sleep(sec) Sleep(sec * 1000)
#define msleep(msec) Sleep(msec)
#else
#include <unistd.h>
#define msleep(msec) usleep(msec * 1000)
#endif

const int MSG_LENTH_NUMBER = 5;  // LV中的L字段的长度

class SocketConnect {
private:
    SOCKET sockClient_{};
    int SendMsg(const char *buff, int buffLength) const;

public:
    SocketConnect() = default;
    virtual ~SocketConnect() = default;

    virtual int Connect(const string& serverIp, unsigned short serverPort);
    virtual int Disconnect();

    virtual int SendMsg(const ClientMsg &clientMsg) const;
    virtual void RecvMsg(char *buffer, int msgSize);
};
