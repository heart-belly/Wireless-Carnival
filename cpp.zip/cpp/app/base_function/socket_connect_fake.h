#pragma once

#include <fstream>
#include "socket_connect.h"

class SocketConnectFake : public SocketConnect{
private:
    string replayFileName_;
    std::ifstream fileStream_;

public:
    explicit SocketConnectFake(string replayFile);
    ~SocketConnectFake() override = default;

    int Connect(const string &serverIp, unsigned short serverPort) override;
    int Disconnect() override;
    int SendMsg(const ClientMsg& clientMsg) const override;
    void RecvMsg(char* buffer, int msgSize) override;
};