#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdarg.h>
#include "log.h"
#include "game_config.h"

#define MAX_FILE_LOG_SIZE 1024000
#define FMT_BUFF_SIZE 256
#define TIME_BUF_LEN 80
#define MAX_LEN_FILE_NAME 256

// 每一行打印的头部定义，包括级别+函数名
#define STR_PROMPT_FUNC_NAME "%-7s %20s %-15s :: "

#define COLOR_WHITE "\033[1;37m"
#define COLOR_GREEN "\033[1;32m"
#define COLOR_CYAN "\033[1;36m"
#define COLOR_RED "\033[1;31m"
#define COLOR_YELLOW "\033[1;33m"
#define COLOR_CLEAR "\033[0m"

typedef struct {
    const char* color;
    const char* prompt;
} LogLevelCfg;

static bool g_isFileLogInit = false;
static bool g_isLogInit = false;
static int g_ownPlayerId = 0;
static char g_fileLogBuf[MAX_FILE_LOG_SIZE] = {0};
static clock_t g_lastClock;
static char g_fileNameToSave[MAX_LEN_FILE_NAME];  // 日志保存的文件的名字
static char g_fileNameInLog[MAX_LEN_FILE_NAME];   // 打印信息里面的文件名

void Pause()
{
    printf("Press Enter to continue...\n");
    fflush(stdout);  // 刷新输出缓冲区
    getchar();
}

static LogLevelCfg logLevelCfg[] = {{COLOR_WHITE, "<DEBUG>"},
                                    {COLOR_GREEN, "<INFO>"},
                                    {COLOR_YELLOW, "<WARN>"},
                                    {COLOR_RED, "<ERROR>"}};
static void BuildFmtBuf(unsigned int outLevel, const char* file, const char* funcName, const char* fmt, bool enColor,
                        char* fmtBuf, unsigned int fmtBufSize)
{
    int ret;
    // 静态函数的入参合法性由调用者负责
    const char* prompt = logLevelCfg[outLevel].prompt;
    const char* color = logLevelCfg[outLevel].color;

    // 把函数名字加到format格式化字符串的前面
    if (enColor) {
        ret = snprintf(fmtBuf, fmtBufSize, "%s" STR_PROMPT_FUNC_NAME "%s" COLOR_CLEAR, color, prompt, file, funcName,
                       fmt);
    } else {
        ret = snprintf(fmtBuf, fmtBufSize, STR_PROMPT_FUNC_NAME "%s", prompt, file, funcName, fmt);
    }

    if (ret < 0) {
        // 源字符串长度过长进入此分支，snprintf_s会截断src中多余的部分，所以打印的内容会不完整，可能丢掉后面的颜色恢复部分
        // 所以安全起见，重新用snprintf构造不带颜色显示的fmtbuf，并截断多余的部分
        if (snprintf(fmtBuf, fmtBufSize, "[ERROR] over-long print in func [%s]\n", funcName) < 0) {
            // 会导致fmtBuf中的内容不全，但是也可以协助定位，所以无需特殊处理
            return;
        }
    }
}

static void PrintToFile()
{
    // 写入文件
    if (!g_isFileLogInit) {
        snprintf(g_fileNameToSave, MAX_LEN_FILE_NAME, "Respect_%d.txt", g_ownPlayerId);
        g_isFileLogInit = true;
        remove(g_fileNameToSave);
    }

    FILE* fp = fopen(g_fileNameToSave, "a");
    if (fp == NULL) {
        printf("error in log\n");
        return;
    }

    g_fileLogBuf[MAX_FILE_LOG_SIZE - 1] = '\0';
    clock_t cur = clock();
    double cpu_time_used = ((double)cur - g_lastClock) / CLOCKS_PER_SEC;
    g_lastClock = cur;
    time_t rawtime;
    struct tm* info;
    char buffer[TIME_BUF_LEN];

    time(&rawtime);

    info = localtime(&rawtime);
    strftime(buffer, TIME_BUF_LEN, "%H:%M:%S", info);
    fprintf(fp, "[%s %lf] %s", buffer, cpu_time_used, g_fileLogBuf);
    fclose(fp);
}

static void GetFilename(const char* path, char* filename)
{
    // 查找最后一个目录分隔符的位置
    const char* slash = strrchr(path, '/');
    if (slash == NULL) {
        // 如果没有找到 '/'，尝试查找 '\\'
        slash = strrchr(path, '\\');
    }

    if (slash != NULL) {
        // 提取文件名
        strcpy(filename, slash + 1);
    } else {
        // 如果没有找到目录分隔符，整个路径就是文件名
        strcpy(filename, path);
    }
}

void LOG_Print(LogLevel level, const char* file, const char* func, const char* fmt, ...)
{
    char fmtBuf[FMT_BUFF_SIZE] = {0};

    if (!g_isLogInit) {
        printf("Log not init, can't print\n");
        return;
    }

    if (level > LEVEL_ERROR || file == NULL || func == NULL || fmt == NULL) {
        return;
    }

    if ((PRINT_LEVEL_MASK & (1 << (unsigned int)level)) == 0) {
        return;
    }

    GetFilename(file, g_fileNameInLog);

#ifdef EN_COLOR_PRINT
    BuildFmtBuf(level, g_fileNameInLog, func, fmt, true, fmtBuf, FMT_BUFF_SIZE);
#else
    BuildFmtBuf(level, g_fileNameInLog, func, fmt, false, fmtBuf, FMT_BUFF_SIZE);
#endif

    va_list args1;
    va_list args2;
    va_start(args1, fmt);
    va_copy(args2, args1);
    if (level == LEVEL_ERROR) {
        vprintf(fmtBuf, args1);
    }
    int ret = vsnprintf(g_fileLogBuf, MAX_FILE_LOG_SIZE, fmtBuf, args2);
    va_end(args1);

    if (ret < 0) {
        printf("vsprintf_s failed\n");
        return;
    }

    PrintToFile();
}

void LOG_Init(int playerId)
{
    g_ownPlayerId = playerId;
    g_isLogInit = true;
}