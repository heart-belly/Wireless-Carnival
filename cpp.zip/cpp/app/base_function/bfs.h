#pragma once

#include <vector>
#include "pos.h"

std::vector<Pos> BFS_FindPath(const std::vector<std::vector<int> > &grid, const Pos &start, const Pos &end);
std::vector<Pos> aStar_FindPath(const std::vector<std::vector<int> > &grid, const Pos &start, const Pos &end);
bool BFS_GetNextMove(const std::vector<std::vector<int> > &grid, const Pos &start, const Pos &end, Pos &next);
bool BFS_GetNextMove(const std::vector<std::vector<int> > &grid, const Pos &start, const Pos &end, Pos &next, int &length);
int BFS_GetDistance(const std::vector<std::vector<int> > &grid, const Pos &start, const Pos &end);