#include "socket_connect.h"
#include "client_msg.h"

int SocketConnect::Connect(const string& serverIp, unsigned short serverPort)
{
#if WIN32
    /* 初始化 */
    WORD wVersionRequested = MAKEWORD(1, 1);
    WSADATA wsAdata;
    if (0 != WSAStartup(wVersionRequested, &wsAdata))  // 完成对Winsock服务的初始化
    {
        return -1;
    }

    if ((LOBYTE(wsAdata.wVersion) != 1) || (HIBYTE(wsAdata.wVersion) != 1)) {
        WSACleanup();
        return -1;
    }
#endif

    /* 创建socket */
    SOCKET client = socket(AF_INET, SOCK_STREAM, 0);

    /* 连接server */
    sockaddr_in addrSrv{};
    // 将IP地址从字符串格式转换为网络字节序
    addrSrv.sin_addr.s_addr = inet_addr(serverIp.c_str());
    addrSrv.sin_family = AF_INET;
    addrSrv.sin_port = htons(serverPort);

    PRINT_INFO("try to connect server(%s:%u)", inet_ntoa(addrSrv.sin_addr), ntohs(addrSrv.sin_port));
    while (0 != connect(client, (sockaddr*)&addrSrv, sizeof(sockaddr))) {
        msleep(10);
    }
    PRINT_INFO("connect server success(%s:%u)", inet_ntoa(addrSrv.sin_addr), ntohs(addrSrv.sin_port));

    sockClient_ = client;
    return 0;
}

int SocketConnect::Disconnect()
{
#if WIN32
    shutdown(sockClient_, SD_BOTH);
    closesocket(sockClient_);
    WSACleanup();
#else
    close(sockClient_);
#endif
    PRINT_INFO("Disconnect");
    return 0;
}

int SocketConnect::SendMsg(const char* buff, int buffLength) const
{
    int ret = (int)send(sockClient_, buff, buffLength, 0);
    PRINT_INFO("******************* SendMsg len=%d ret=%d\n%s", buffLength, ret, buff);
    return ret;
}

void SocketConnect::RecvMsg(char* buffer, int msgSize)
{
    int size = 0;

    while (size < msgSize) {
        int len = (int)recv(sockClient_, buffer + size, msgSize - size, 0);
        if (len < 0) {
            PRINT_ERROR("recv return %d error!", len);
            return;
        }
        size += len;
    }
}

int SocketConnect::SendMsg(const ClientMsg& clientMsg) const
{
    string jsonStr = "invalid msg";
    clientMsg.ToJsonStr(jsonStr);
    return SendMsg(jsonStr.c_str(), (int)jsonStr.size());
}
