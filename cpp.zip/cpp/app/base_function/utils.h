#pragma once

#include <vector>
#include <algorithm>
#include <locale>

template <typename T>
bool Contains(const std::vector<T> &vec, const T &value)
{
    return std::find(vec.begin(), vec.end(), value) != vec.end();
}

std::vector<std::string> split(const std::string &str, char c);
