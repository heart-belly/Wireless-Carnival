#include "game_context.h"
#include "game_config.h"

static GameContext g_gameContext;

GameContext& GameContext::Instance()
{
    return g_gameContext;
}

void GameContext::SetOwnPlayerId(int playerId)
{
    ownPlayerId_ = playerId;
}

int GameContext::GetOwnPlayerId() const
{
    return ownPlayerId_;
}

/*
 * 计算进攻的方向，1为向右侧进攻，-1为向左侧进攻
 */
int GameContext::CalcAttackDirection()
{
    Base& base = initialInfo_.buildings.bases[0];
    if (base.playerId == ownPlayerId_) {
        if (base.detail.poses[0].x_ < 25) {
            // 己方基地在左侧，向右侧进攻
            return 1;
        } else {
            return -1;
        }
    } else {
        if (base.detail.poses[0].x_ < 25) {
            // 对方基地在左侧，向左侧进攻
            return -1;
        } else {
            return 1;
        }
    }
}

void GameContext::UpdateByStartMsg(const GameInitialInfo& initialInfo)
{
    // 更新游戏的初始信息
    initialInfo_ = initialInfo;

    CreateHero(initialInfo.heroesInfo);

    // 更新地图
    InitMap(initialInfo.map);
    initialMap_.Print();

    direction_ = CalcAttackDirection();
    PRINT_WARN("进攻方向为%d", direction_);
}

// 初始化地图
void GameContext::InitMap(const StaticMap& map)
{
    int index = 0;

    initialMap_.maxX = map.maxX;
    initialMap_.maxY = map.maxY;
    for (int i = 0; i < map.maxY; i++) {
        vector<int> row;
        for (int j = 0; j < map.maxX; j++) {
            row.push_back(map.data[index++]);
        }
        // 刚开始的是上面一行
        initialMap_.mapValue_.insert(initialMap_.mapValue_.begin(), row);
    }
}

void GameContext::UpdateByInquireMsg(const GameRoundInfo& roundInfo)
{
    PRINT_WARN("********************************第%d轮开始*******************************************",
               roundInfo.round);

    if (g_maxRound != -1 && roundInfo.round >= g_maxRound) {
        Pause();
        throw std::runtime_error("超过预期的轮数，结束游戏");
    }

    roundInfo_ = roundInfo;
    UpdateHero(roundInfo.heroesInfo);
    UpdateRoundMap(roundInfo);
    UpdateRiskMap();

    // 打印所有对方英雄的信息
    for (auto tmp : GetMyHeroes()) {
        PRINT_INFO("我方英雄： %s", tmp->ToString().c_str());
    }
    for (auto tmp : GetOppHeroInfo()) {
        PRINT_INFO("对方英雄： %s", tmp.ToString().c_str());
    }
}

void GameContext::CreateHero(const vector<HeroInfo>& heroInfoList)
{
    for (const auto& heroInfo : heroInfoList) {
        if (heroInfo.playerId != ownPlayerId_) {
            continue;
        }
        Hero* curHero = new Hero(HeroCharacter::CreateHero(heroInfo.heroType));

        curHero->SetHeroInfo(heroInfo);
        PRINT_WARN("add new heroType id=%d", curHero->GetHeroType());
        if (curHero->GetHeroKind() == HERO_FRONT) {
            // 前排放在前面，这样指令先执行，方便后排跟随
            myHeroes_.insert(myHeroes_.begin(), curHero);
        } else {
            myHeroes_.push_back(curHero);
        }
    }
}

void GameContext::UpdateHero(const vector<HeroInfo>& heroInfoList)
{
    for (const auto& heroInfo : heroInfoList) {
        if (heroInfo.playerId != ownPlayerId_) {
            continue;
        }
        for (const auto& oneHero : myHeroes_) {
            if (oneHero->GetId() == heroInfo.heroId) {
                oneHero->SetHeroInfo(heroInfo);
                break;
            }
        }
    }
}

int GameContext::GetRound() const
{
    return roundInfo_.round;
}

const Shop& GameContext::GetShop() const
{
    return initialInfo_.buildings.shop;
}

Map GameContext::GetRoundMap()
{
    return roundMap_;
}

Map GameContext::GetinitMap()
{
    return initialMap_;
}

const Base* GameContext::GetMyBase() const
{
    for (const auto& base : roundInfo_.buildings.bases) {
        if (base.playerId == ownPlayerId_) {
            return &base;
        }
    }
    return nullptr;
}

const Base* GameContext::GetOppBase() const
{
    for (const auto& base : roundInfo_.buildings.bases) {
        if (base.playerId != ownPlayerId_) {
            return &base;
        }
    }
    return nullptr;
}

vector<SoldierDetail> GameContext::GetMySoldiers() const
{
    for (const auto& soldier : roundInfo_.soldiers) {
        if (soldier.playerId == ownPlayerId_) {
            return soldier.details;
        }
    }
    return {};
}
// 得到敌方英雄的信息
vector<HeroInfo> GameContext::GetOppAliveHeroInfo() const
{
    vector<HeroInfo> heroInfoList;

    for (const auto& heroInfo : roundInfo_.heroesInfo) {
        if (heroInfo.playerId != ownPlayerId_ && !heroInfo.isDead) {
            heroInfoList.push_back(heroInfo);
        }
    }
    return heroInfoList;
}
// 得到我方英雄的信息
vector<HeroInfo> GameContext::GetMyAliveHeroInfo() const
{
    vector<HeroInfo> heroInfoList;

    for (const auto& heroInfo : roundInfo_.heroesInfo) {
        if (heroInfo.playerId == ownPlayerId_ && !heroInfo.isDead) {
            heroInfoList.push_back(heroInfo);
        }
    }
    return heroInfoList;
}

vector<HeroInfo> GameContext::GetOppHeroInfo() const
{
    vector<HeroInfo> heroInfoList;

    for (const auto& heroInfo : roundInfo_.heroesInfo) {
        if (heroInfo.playerId != ownPlayerId_) {
            heroInfoList.push_back(heroInfo);
        }
    }
    return heroInfoList;
}

vector<SoldierDetail> GameContext::GetOppSoldiers() const
{
    for (const auto& soldier : roundInfo_.soldiers) {
        if (soldier.playerId != ownPlayerId_) {
            return soldier.details;
        }
    }
    return {};
}

vector<TowerDetail> GameContext::GetOppTowers() const
{
    for (const auto& tower : roundInfo_.buildings.towers) {
        if (tower.playerId != ownPlayerId_) {
            return tower.details;
        }
    }
    return {};
}

/*
 * 获取地方所有可移动目标的信息
 */
vector<Unit> GameContext::GetOppUnit() const
{
    vector<Unit> ans;

    for (const auto& hero : GetOppHeroInfo()) {
        if (hero.isDead) {
            continue;
        }
        Unit tmp;
        tmp.type = HERO;
        tmp.hp = hero.hp;
        tmp.pos = hero.pos;
        ans.push_back(tmp);
    }

    for (const auto& soldier : GetOppSoldiers()) {
        Unit tmp;
        tmp.type = SOLDIER;
        tmp.hp = soldier.hp;
        tmp.pos = soldier.pos;
        ans.push_back(tmp);
    }
    return ans;
}

/*
 * 获取敌方所有防御塔，含基地的必要信息
 */
vector<DefenseTower> GameContext::GetOppDefenseTower() const
{
    vector<DefenseTower> ans;

    for (const auto& tower : GetOppTowers()) {
        DefenseTower tmp;
        tmp.type = TOWER;
        tmp.hp = tower.hp;
        tmp.poses = tower.poses;
        ans.push_back(tmp);
    }

    const Base* base = GetOppBase();
    if (base != nullptr) {
        DefenseTower tmp;
        tmp.type = BASE;
        tmp.hp = base->detail.hp;
        tmp.poses = base->detail.poses;
        ans.push_back(tmp);
    }

    return ans;
}

/*
 * 获取我方所有防御塔，含基地的必要信息
 */
vector<DefenseTower> GameContext::GetMyDefenseTower() const
{
    vector<DefenseTower> ans;

    for (const auto& tower : GetMyTowers()) {
        DefenseTower tmp;
        tmp.hp = tower.hp;
        tmp.poses = tower.poses;
        ans.push_back(tmp);
    }

    const Base* base = GetMyBase();
    if (base != nullptr) {
        DefenseTower tmp;
        tmp.hp = base->detail.hp;
        tmp.poses = base->detail.poses;
        ans.push_back(tmp);
    }

    return ans;
}

vector<TowerDetail> GameContext::GetMyTowers() const
{
    for (const auto& tower : roundInfo_.buildings.towers) {
        if (tower.playerId == ownPlayerId_) {
            return tower.details;
        }
    }
    return {};
}

const vector<Hero*> GameContext::GetMyAliveHeroes() const
{
    vector<Hero*> ans;
    for (auto tmp : myHeroes_) {
        if (tmp->IsDead()) {
            continue;
        }
        ans.push_back(tmp);
    }
    return ans;
}

const vector<Hero*>& GameContext::GetMyHeroes() const
{
    return myHeroes_;
}

void GameContext::UpdateRoundMap(const GameRoundInfo& info)
{
    roundMap_ = initialMap_;

    // 将塔标记为不可达
    for (const auto& tower : info.buildings.towers) {
        for (const auto& detail : tower.details) {
            for (Pos pos : detail.poses) {
                roundMap_.SetValue(pos, TOWER);
            }
        }
    }

    for (const auto& base : info.buildings.bases) {
        for (const auto& pos : base.detail.poses) {
            roundMap_.SetValue(pos, BASE);
        }
    }

    // 小兵位置不可达
    for (const auto& soldier : info.soldiers) {
        for (const auto& detail : soldier.details) {
            roundMap_.SetValue(detail.pos, SOLDIER);
        }
    }

    // 英雄位置不可达
    for (const auto& heroInfo : info.heroesInfo) {
        roundMap_.SetValue(heroInfo.pos, HERO);
    }

    // 野怪位置不可达
    if (info.monster.isValid) {
        roundMap_.SetValue(info.monster.pos, MONSTER);
    }
}

void GameContext::UpdateRiskMap()
{
    riskMap_ = roundMap_;

    // 所有敌方英雄和防御塔的攻击范围为危险区域
    for (const auto& oppHero : GetOppAliveHeroInfo()) {
        riskMap_.SetValueAround(oppHero.pos, 3, CHEBYSHEV, DANGER);
    }

    for (const auto& oppTower : GetOppTowers()) {
        for (auto pos : oppTower.poses) {
            riskMap_.SetValueAround(pos, 4, MANHATTAN, DANGER);
        }
    }

    for (auto pos : GetOppBase()->detail.poses) {
        riskMap_.SetValueAround(pos, 4, MANHATTAN, DANGER);
    }
}

Rune GameContext::GetRune() const
{
    return roundInfo_.runes;
}

/*
 * 向右侧进攻为1
 */
int GameContext::GetDirection() const
{
    return direction_;
}

/*
 * 获取己方的另外一个英雄
 */
Hero* GameContext::GetTeammate(const Hero& hero)
{
    for (auto myHero : myHeroes_) {
        if (myHero->GetId() != hero.GetId() && !myHero->IsDead()) {
            return myHero;
        }
    }
    return nullptr;
}
// 判断我方小兵是不是在防御塔内
bool GameContext::IsMySoldierInRange(DefenseTower defenseTower) const
{
    for (const auto& soldier : GetMySoldiers()) {
        for (auto pos : defenseTower.poses) {
            int distance = pos.CalcDistance(soldier.pos, MANHATTAN);
            if (distance <= 4) {
                return true;
            }
        }
    }
    return false;
}
// 判断我方英雄是不是在防御塔内
bool GameContext::IsMyHeroInRange(DefenseTower defenseTower) const
{
    for (const auto& hero :  GetMyAliveHeroInfo()) {
        for (auto pos : defenseTower.poses) {
            int distance = pos.CalcDistance(hero.pos, MANHATTAN);
            if (distance <= 4) {
                return true;
            }
        }
    }
    return false;
}

// 判断敌方小兵是不是在防御塔内
bool GameContext::IsOppSoldierInRange(DefenseTower defenseTower) const
{
    for (const auto& soldier : GetOppSoldiers()) {
        for (auto pos : defenseTower.poses) {
            int distance = pos.CalcDistance(soldier.pos, MANHATTAN);
            if (distance <= 4) {
                return true;
            }
        }
    }
    return false;
}

// 返回敌方小兵在我方防御塔内的数量
int GameContext::GetOppSoldierInRangeNumber(DefenseTower defenseTower) const
{   int cnt = 0;
    for (const auto& soldier : GetOppSoldiers()) {
        for (auto pos : defenseTower.poses) {
            int distance = pos.CalcDistance(soldier.pos, MANHATTAN);
            if (distance <= 4) {
                cnt ++;
            }
        }
    }
    return cnt;
}

// 判断敌方英雄是不是方防御塔内
bool GameContext::IsOppHeroInRange(DefenseTower defenseTower) const
{
    for (const auto& hero :GetOppAliveHeroInfo()) {
        for (auto pos : defenseTower.poses) {
            int distance = pos.CalcDistance(hero.pos, MANHATTAN);
            if (distance <= 4) {
                return true;
            }
        }
    }
    return false;
}

Map GameContext::GetRiskMap() const
{
    return riskMap_;
}
