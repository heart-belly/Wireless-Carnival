#pragma once

#include <vector>
#include <iostream>
#include <sstream>
#include "pos.h"
#include "equip.h"
#include "skill.h"
#include "hero_type.h"
#include <unordered_map>

using namespace std;

struct StaticMap {
    int maxX;
    int maxY;
    std::vector<int> data;
};

struct ActionOfTower {
    ActionType type = IDLE;
    Pos target;
};

struct TowerDetail {
    vector<Pos> poses;
    int hp;
    int maxHp;
    int atk;
    int atkDis;
    // 可选
    int id;
    ActionOfTower action;
    int hateId;
};

struct Tower {
    int playerId;
    vector<TowerDetail> details;
};

struct Base {
    int playerId{};
    TowerDetail detail;
};

struct Equipment {
    EquipType type;
    int price;
    int cd;
    int duration;
};

struct Grass {
    int id;
    vector<Pos> poses;
    int type;
};

struct Shop {
    vector<Pos> poses;
    vector<Equipment> equipments;
};

struct Buildings {
    vector<Base> bases;
    vector<Tower> towers;
    // 可选，只在start里面有
    Shop shop;
};

struct Status {
    int debuffImmu;
    int dizzy;
    int phyDamageImmu;
    int magicDamageImmu;
    int cantMove;
    int cantAttack;
    int doubleAttack;
    int halfAttack;
    int targeted;
    int teleporting;
};

struct Skill {
    // 必须项目
    SkillId skillId{};
    int cd{};
    int duration{};

    // 可选项
    int cdRemainRound{};
    int durationRemainRound{};
    int attackRange{};
    int attackCenter{};
};

struct Action {
    ActionType type;
    EquipType useEquipId;
    int skillId;
    Pos targetPos;
    vector<EquipType> buyEquipIds;

    void InitAttack(const Pos& pos);
    void InitMove(Pos nextPos);
    void InitIdle();
    void InitBuyEquip(vector<EquipType> equipIdList);
    void InitUseEquip(EquipType id);
    void InitUseEquip(EquipType id, Pos target);
    void InitSkill(SkillId id, Pos target);
    void InitRevive();

    void Clear()
    {
        type = IDLE;
        useEquipId = INVALID_EQUIP;
        skillId = 0;
        targetPos = Pos(0, 0);
        buyEquipIds.clear();
    }
};

struct Monster {
    bool isValid;   // 有时候消息里面会没有monster
    int hp = 0;
    int maxHp = 0;
    int atk = 0;
    int atkDis = 0;
    Pos pos{};

    // 以下可选
    int id;
    Pos bornPos{};
    int bornRound = 0;
    int refreshPeriod = 0;
    Action action;
    bool sleeping;
    int hateId;
};

struct EquipmentOfHero {
    int cd{};
    int cdRemain{};
    int type{};
};

enum EnemyType { ENEMY_HERO = 1, ENEMY_SOLDIER, ENEMY_BUILDING };

struct HeroInfo {
    // 必须项目
    int playerId{};
    int heroId{};
    Pos pos;
    int hp{};
    int maxHp{};
    int atk{};
    int atkDis{};
    HeroType heroType{};
    // 决赛新新增字段
    int buyLiveCost{};
    int buyLiveRemainRound{};


    // 可选项目
    Pos bornPos;  // start特有
    vector<Skill> skills;
    bool isDead{};
    int reviveRound{};
    int money{};
    int rewardMoney{};
    bool isSeen{};
    Action action;
    Status status;
    vector<EquipmentOfHero> equipments;

    string ToString() const;
};

struct SoldierDetail {
    int id{};
    Pos pos;
    int hp{};
    int maxHP{};
    int type{};
    int hateId{};

    struct Status {
        int cantAttack;
        int cantMove;
        int dizzy;
        int magicDamageImmu;
        int phyDamageImmu;
    } status{};
};

struct Player {
    int playerId;
    string name;
    vector<HeroInfo> heroesInfo;
};

struct HeroAction {
    int id{};
    Action action;
};

struct Soldier {
    int playerId;
    // 可选项
    vector<SoldierDetail> details;
};

struct SoldierInitial {
    vector<Pos> bornPos;
    int bornRound;
    int playerId;
    int refreshPeriod;
};

struct CampInfo {
    int playerId;
    string name;
    int money;
    int killNum;
    int killTower;
};

struct VictoryCamp {
    int playerId;
    string name;
};

struct RunesInitial {
    Pos pos;
    int bornRound{};
    int refreshPeriod{};
};

// 游戏的初始信息
struct GameInitialInfo {
    StaticMap map;
    vector<HeroInfo> heroesInfo;
    Buildings buildings;
    vector<SoldierInitial> soldierList;
    RunesInitial runes;
    Monster monster;
};

// 每轮的符文信息，可能为空，所以增加了isValid字段
struct Rune {
    bool isValid = false;
    int id{};
    Pos pos;
    RuneType type;
};

// 游戏当前轮次的信息
struct GameRoundInfo {
    int round;
    Buildings buildings;
    vector<HeroInfo> heroesInfo;
    vector<Soldier> soldiers;
    vector<CampInfo> campsInfo;
    Rune runes;
    Monster monster;
};