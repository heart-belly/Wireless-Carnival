#include <unordered_map>
#include "skill.h"
#include "pos.h"
#include "game_context.h"

// 生成技能查找表
std::unordered_map<SkillId, SkillCfg> g_commonSkillCfgTable = {
    {NATURE_GRASP, {0, 2, OPP_ALL}},        // 1003
    {LEECH_SEED, {1, 0, OPP_ALL}},          // 1004
    {LAGUNA_BLADE, {3, 0, OPP_ALL}},       // 1006
    {LIGHT_STRIKE_ARRAY, {2, 1, OPP_ALL}},  // 1007
    {FREEZING_FIELD, {0, 3, OPP_ALL}},      // 1009
    {FROSTBITE, {3, 0, OPP_HERO}},          // 1010
    {ASSASSINATE, {6, 0, OPP_HERO}},        // 1012 距离从6改为4，这样对手无法逃脱
    {SHRAPNEL, {3, 2, OPP_ALL}},            // 1013
    {LIFE_BREAK, {3, 0, OPP_HERO}},         // 1015
    {INNER_FIRE, {3, 0, OPP_ALL}},          // 1016
    {POISON_TOUCH, {3, 0, OPP_HERO}}        // 1021
};

// 根据技能枚举查找技能配置
SkillCfg* GetSkillCfg(SkillId skillId)
{
    auto it = g_commonSkillCfgTable.find(skillId);
    if (it != g_commonSkillCfgTable.end()) {
        return &it->second;
    } else {
        return nullptr;  // 如果未找到，返回空指针
    }
}

// 定义技能名字映射表
std::unordered_map<SkillId, std::string> g_skillNameMap = {{MEAT_HOOK, "肉钩"},          {DISMEMBER, "腐烂"},
                                                           {NATURE_GRASP, "疯狂生长"},   {LEECH_SEED, "寄生种子"},
                                                           {LAGUNA_BLADE, "神灭斩"},     {LIGHT_STRIKE_ARRAY, "光击阵"},
                                                           {FREEZING_FIELD, "极寒领域"}, {FROSTBITE, "冰封禁止"},
                                                           {ASSASSINATE, "狙击"},        {SHRAPNEL, "榴霰弹"},
                                                           {LIFE_BREAK, "牺牲"},         {INNER_FIRE, "沸血之矛"},
                                                           {GUARDIAN_ANGEL, "守护天使"}, {PURIFICATION, "天国恩赐"},
                                                           {SHALLOW_GRAVE, "薄葬"},      {POISON_TOUCH, "迷魂"}};

std::string GetSkillName(SkillId skillId)
{
    auto it = g_skillNameMap.find(skillId);
    if (it != g_skillNameMap.end()) {
        return it->second;
    } else {
        return "技能未找到";  // 或者返回一个空字符串，或者其他默认值
    }
}

bool IsInSkillRange(const Pos src, const Pos& target, SkillId skillId, Pos& skillReleasePos)
{
    SkillCfg* skillCfg = GetSkillCfg(skillId);
    if (skillCfg == nullptr) {
        PRINT_ERROR("skillCfg == nullptr %d", skillId);
        return false;
    }

    return IsInSkillRange(src, target, skillCfg->castDistance, skillCfg->castRange, skillReleasePos);
}

bool IsInSkillRange(const Pos src, const Pos& target, int castDistance, int castRange, Pos& skillReleasePos)
{
    for (int dx = -castDistance; dx <= castDistance; ++dx) {
        for (int dy = -castDistance; dy <= castDistance; ++dy) {
            const Pos skillReleasePoint = {src.x_ + dx, src.y_ + dy};
            // 检查技能释放点是否在地图范围内
            if (!GameContext::Instance().GetRoundMap().IsWithinMap(skillReleasePoint)) {
                continue;
            }
            if (skillReleasePoint.IsNeighbor(target, castRange, CHEBYSHEV)) {
                skillReleasePos = skillReleasePoint;
                return true;
            }
        }
    }
    return false;
}