#include <iomanip>
#include <cstdint>
#include "map.h"
#include "utils.h"
#include "bfs.h"
#include "log.h"

void Map::Print() const
{
    std::ostringstream oss;

    oss << "\nthe map is: " << endl;
    for (int i = mapValue_.size() - 1; i >= 0; --i) {
        for (int j = 0; j < mapValue_[i].size(); ++j) {
            if (mapValue_[i][j] == 0) {
                oss << "." << " ";
            } else {
                oss << mapValue_[i][j] << " ";
            }
        }
        oss << endl;
    }
    oss << endl;

    PRINT_DEBUG("the map is: \n%s", oss.str().c_str());
}

// 找到目标点中最近的一个点，返回下一个移动位置
FindPathResult Map::GetNextPos(const Pos& src, const vector<Pos>& targetList, Pos& next) const
{
    Pos target;
    return GetNextPos(src, targetList, next, target);
}

FindPathResult Map::GetNextPos(const Pos& src, const vector<Pos>& targetList, Pos& next, Pos& target) const
{
    int pathLength = 0;
    return GetNextPos(src, targetList, next, target, pathLength);
}

// 寻找源到一系列目标点之间的，最短的距离，将下一步的移动位置存放到next，选中的目标点放到target
FindPathResult Map::GetNextPos(const Pos& src, const vector<Pos>& targetList, Pos& next, Pos& target, int &pathLength) const
{
    if (Contains(targetList, src)) {
        return ALREADY_AT_DESTINATION;
    }

    Pos tmp;
    int length = 0;
    int minLength = INT32_MAX;
    bool find = false;
    for (Pos oneTarget : targetList) {
        if (BFS_GetNextMove(mapValue_, src, oneTarget, tmp, length)) {
            find = true;
            if (length < minLength) {
                next = tmp;
                target = oneTarget;
                minLength = length;
            }
        }
    }

    pathLength = minLength;
    return find ? PATH_FOUND : PATH_NOT_FOUND;
}

// 判断给定坐标是否在地图范围内
bool Map::IsWithinMap(const Pos& pos) const
{
    return pos.x_ >= 0 && pos.x_ < maxX && pos.y_ >= 0 && pos.y_ < maxY;
}

void Map::SetValue(const Pos& pos, MapPosType type)
{
    if (!IsWithinMap(pos)) {
        return;
    }
    mapValue_[pos.y_][pos.x_] = type;
}

MapPosType Map::GetValue(const Pos& pos)
{
    if (!IsWithinMap(pos)) {
        // 非法位置都认为是障碍
        return WALL;
    }
    return (MapPosType)mapValue_[pos.y_][pos.x_];
}

bool Map::IsReachable(MapPosType type)
{
    switch (type) {
        case SPACE:
        case GRASS:
            return true;
        default:
            return false;
    }
}

bool Map::IsReachable(Pos pos) const
{
    if (!IsWithinMap(pos)) {
        return false;
    }

    return IsReachable((MapPosType)mapValue_[pos.y_][pos.x_]);
}

void Map::SetValueAround(Pos pos, int distance, DistanceType distanceType, MapPosType posType)
{
    for (int dx = -distance; dx <= distance; dx++) {
        for (int dy = -distance; dy <= distance; dy++) {
            if (dx == 0 && dy == 0) {
                continue;
            }
            if (distanceType == MANHATTAN && (abs(dx) + abs(dy)) > distance) {
                continue;
            }
            SetValue(pos + Pos(dx, dy), posType);
        }
    }
}

bool Map::IsDanger(const Pos& pos)
{
    return GetValue(pos) == DANGER;
}
