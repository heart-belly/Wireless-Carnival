#pragma once

#include "base_type.h"

std::string GetEquipName(EquipType equipId);
int GetEquipPrice(EquipType equipId);
std::string getRuneName(RuneType runeType);