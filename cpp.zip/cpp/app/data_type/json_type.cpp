#include "json_type.h"
#include "skill.h"
#include "log.h"
#include <utility>

string HeroInfo::ToString() const
{
    std::ostringstream oss;
    string dead = isDead ? "dead" : "alive";
    oss << "HeroInfo { " << "id: " << heroId << ", name: " << GetHeroName(heroType) << ", pos: " << pos.toString()
        << ", hp: " << hp << ", " << dead << " }";
    return oss.str();
}

void Action::InitAttack(const Pos& pos)
{
    Clear();
    type = ATTACK;
    targetPos = pos;
    PRINT_INFO("attack %s", pos.toString().c_str());
}

void Action::InitMove(Pos nextPos)
{
    Clear();
    type = MOVE;
    targetPos = nextPos;
    PRINT_INFO("move to %s", nextPos.toString().c_str());
}

void Action::InitIdle()
{
    Clear();
    type = IDLE;
    PRINT_INFO("idle");
}

void Action::InitBuyEquip(vector<EquipType> equipIdList)
{
    Clear();
    type = BUY_EQUIP;
    buyEquipIds = std::move(equipIdList);
    string equipName;
    for (auto equip : equipIdList) {
        equipName.append(GetEquipName(equip));
        equipName.append(",");
    }
    PRINT_INFO("buy equip %s", equipName.c_str());
}

void Action::InitUseEquip(EquipType id)
{
    Clear();
    type = USE_EQUIP;
    useEquipId = id;
    PRINT_INFO("use equip %s", GetEquipName(id).c_str());
}

void Action::InitSkill(SkillId id, Pos target)
{
    Clear();
    type = SKILL;
    skillId = id;
    targetPos = target;
    PRINT_INFO("cast skill %s, targetPos %s", GetSkillName(id).c_str(), target.toString().c_str());
}

void Action::InitUseEquip(EquipType id, Pos target)
{
    Clear();
    type = USE_EQUIP;
    useEquipId = id;
    targetPos = target;
    PRINT_INFO("use equip %s, target %s", GetEquipName(id).c_str(), target.toString().c_str());
}

void Action::InitRevive() {
    Clear();
    type = BUY_REVIVE;
    PRINT_INFO("USE REVIVE");
}
