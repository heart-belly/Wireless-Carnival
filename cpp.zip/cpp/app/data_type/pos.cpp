#include "pos.h"
#include "log.h"
#include "vector"

using namespace std;

std::string Pos::toString() const
{
    return "(" + std::to_string(x_) + ", " + std::to_string(y_) + ")";
}

std::ostream &operator<<(std::ostream &os, const Pos &pos)
{
    os << pos.toString();
    return os;
}

static const Pos directions[]
    = {Pos(-1, 1), Pos(0, 1), Pos(1, 1), Pos(-1, 0), Pos(1, 0), Pos(-1, -1), Pos(0, -1), Pos(1, -1)};

Pos Pos::GetNeighbor(Direction direction) const
{
    if (direction > RIGHT_DOWN) {
        PRINT_ERROR("invalid direction %d", direction);
        return {};
    }
    return *this + directions[direction];
}

int Pos::CalcDistance(Pos other, DistanceType type) const
{
    int ans;
    switch (type) {
        case MANHATTAN:
            ans = abs(x_ - other.x_) + abs(y_ - other.y_);
            break;
        case CHEBYSHEV:
            ans = std::max(std::abs(x_ - other.x_), std::abs(y_ - other.y_));
            break;
        default:
            PRINT_ERROR("unknown type");
            return -1;
    }
//     PRINT_WARN("type %d src %s other %s is %d", type, this->toString().c_str(), other.toString().c_str(), ans);
    return ans;
}

bool Pos::IsNeighbor(const Pos &other, int distance, DistanceType type) const
{
//     PRINT_WARN("distance %d", distance);
    return CalcDistance(other, type) <= distance;
}

vector<Pos> Pos::GetNeighbor() const
{
    vector<Pos> ans;
    for (auto tmp : directions) {
        ans.push_back(*this + tmp);
    }
    return ans;
}
