#ifndef BASE_TYPE_H
#define BASE_TYPE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum { MOVE = 20, ATTACK, SKILL, BUY_EQUIP, USE_EQUIP, IDLE, BUY_REVIVE = 30 } ActionType;

typedef enum {
    MEAT_HOOK = 1000,           // 肉钩
    DISMEMBER = 1001,           // 腐烂
    NATURE_GRASP = 1003,        // 疯狂生长
    LEECH_SEED = 1004,          // 寄生种子
    LAGUNA_BLADE = 1006,        // 神灭斩
    LIGHT_STRIKE_ARRAY = 1007,  // 光击阵
    FREEZING_FIELD = 1009,      // 极寒领域
    FROSTBITE = 1010,           // 冰封禁止
    ASSASSINATE = 1012,         // 狙击
    SHRAPNEL = 1013,            // 榴霰弹
    LIFE_BREAK = 1015,          // 牺牲
    INNER_FIRE = 1016,          // 沸血之矛
    GUARDIAN_ANGEL = 1018,      // 守护天使
    PURIFICATION = 1019,        // 天国恩赐
    SHALLOW_GRAVE = 1020,       // 薄葬
    POISON_TOUCH = 1021         // 迷魂
} SkillId;

typedef enum {
    PUDGE = 21,        // 屠夫
    TREANT_PROTECTOR,  // 树精
    LINA,              // 火法师
    CRYSTAL_MAIDEN,    // 冰法师
    SNIPER,            // 火枪手
    HUSKAR,            // 神灵武士
    OMNIKNIGHT,        // 全能骑士
    DARK_SEER,         // 暗影牧师
} HeroType;

typedef enum {
    GOLD = 0,       // 金币
    DOUBLE_ATTACK,  // 双倍攻击
    RECOVERY        // 恢复符
} RuneType;

typedef enum {
    INVALID_EQUIP = 0,
    KELENS_SHEEP = 1,
    MONKEY_KING_BAR = 2,  // 金箍棒	500	使用后英雄的攻击力增加当前攻击力的100%
    BOOTS_OF_TRAVEL,      // 回城卷轴 200 可选择己方任意一座防御塔范围2以内的空地进行传送，2回合后生效，传送期间英雄处于持续施法状态
    KELENS_DAGGER,  // 跳刀	200	从当前位置瞬移到附近距离5以内的任意空地，距离计算参考技能的生效范围
    BLACK_KING_BAR,   // 黑皇杖	500	使用后对敌方英雄的所有技能效果免疫
    GHOST_SCEPTER,    // 绿杖	300	使用后免疫所有单位的普通攻击，同时自身也不可进行普通攻击
    AGHANIM_SCEPTER,  // 神之一手 200 对自身距离2以内的一个敌方小兵或者野怪使用后减少其200血
} EquipType;

#ifdef __cplusplus
}
#endif

#endif /* BASE_TYPE_H */
