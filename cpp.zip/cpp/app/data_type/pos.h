#pragma once

#include <iostream>
#include "vector"

using namespace std;

enum Direction { LEFT_UP = 0, UP, RIGHT_UP, LEFT, RIGHT, LEFT_DOWN, DOWN, RIGHT_DOWN };

// 定义地图上不同点的枚举类型
enum MapPosType {
    SPACE = 0,  // 0 空地
    WALL = 1,   // 1 障碍物
    GRASS = 2,
    // 下面是每轮更新后的元素
    TOWER,
    BASE,
    MONSTER,
    SOLDIER,
    HERO,
    DANGER
};

// 举例计算方法
enum DistanceType {
    MANHATTAN,  // 曼哈顿距离是沿着轴的距离和，即在一个网格系统中从一个点到另一个点的路径距离（只能沿着水平和垂直方向移动）
    CHEBYSHEV  // 切比雪夫距离是两点之间的最大轴向距离，适用于可以沿对角线移动的网格系统
};

class Pos {
public:
    Pos(int x, int y) : x_(x), y_(y) {}
    Pos() : x_(0), y_(0) {}

    int x_;
    int y_;

    Pos operator+(const Pos& other) const
    {
        return Pos(x_ + other.x_, y_ + other.y_);
    }

    bool operator==(const Pos& other) const
    {
        return x_ == other.x_ && y_ == other.y_;
    }

    bool operator!=(const Pos& other) const
    {
        return x_ != other.x_ || y_ != other.y_;
    }

    bool IsNeighbor(const Pos& other, int distance, DistanceType type) const;

    std::string toString() const;

    friend std::ostream& operator<<(std::ostream& os, const Pos& pos);
    int CalcDistance(Pos other, DistanceType type) const;
    Pos GetNeighbor(Direction direction) const;
    vector<Pos> GetNeighbor() const;
};
