#pragma once

#include <vector>
#include "pos.h"

using namespace std;

struct DefenseTower {
    MapPosType type;
    int hp;
    vector<Pos> poses;
};

struct Unit {
    MapPosType type;
    int hp{};
    Pos pos;
};