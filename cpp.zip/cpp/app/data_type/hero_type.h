#pragma once

#include "base_type.h"
#include "pos.h"

enum HeroKind {
    HERO_FRONT = 0,
    HERO_BACK
};

struct HeroCfg {
    int attackDistance;
    int attackHeroDistance;  //火枪特殊
    DistanceType attackType;
};

HeroCfg* GetHeroCfg(HeroType heroType);
std::string GetHeroName(HeroType heroType);
HeroKind GetHeroClass(HeroType heroType);