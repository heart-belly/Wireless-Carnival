#include "hero_type.h"
#include <string>
#include <unordered_map>
#include "base_type.h"

const std::unordered_map<HeroType, std::string> g_heroNameMap = {{PUDGE, "屠夫"},          {TREANT_PROTECTOR, "树精"},
                                                                 {LINA, "火法"},           {CRYSTAL_MAIDEN, "冰法"},
                                                                 {SNIPER, "火枪"},         {HUSKAR, "神灵武士"},
                                                                 {OMNIKNIGHT, "全能骑士"}, {DARK_SEER, "暗影牧师"}};
std::unordered_map<HeroType, HeroCfg> g_HeroCfgMap = {
    {PUDGE, {1, 1, CHEBYSHEV}},          {TREANT_PROTECTOR, {1, 1, CHEBYSHEV}}, {LINA, {3, 3, MANHATTAN}},
    {CRYSTAL_MAIDEN, {3, 3, MANHATTAN}}, {SNIPER, {3, 5, MANHATTAN}},           {HUSKAR, {3, 3, MANHATTAN}},
    {OMNIKNIGHT, {2, 2, MANHATTAN}},     {DARK_SEER, {2, 2, MANHATTAN}}};

HeroCfg* GetHeroCfg(HeroType heroType)
{
    auto it = g_HeroCfgMap.find(heroType);
    if (it != g_HeroCfgMap.end()) {
        return &it->second;
    } else {
        return nullptr;  // 如果未找到，返回空指针
    }
}

std::string GetHeroName(HeroType heroTypeId)
{
    auto it = g_heroNameMap.find(heroTypeId);
    if (it != g_heroNameMap.end()) {
        return it->second;
    }
    return "未知英雄";  // 未找到对应的英雄类型ID
}

HeroKind GetHeroClass(HeroType heroType)
{
    switch (heroType) {
        case PUDGE:
        case TREANT_PROTECTOR:
        case OMNIKNIGHT:
        case DARK_SEER:
        case CRYSTAL_MAIDEN:
            return HERO_FRONT;
        case LINA:
        case SNIPER:
        case HUSKAR:
            return HERO_BACK;
        default:
            return HERO_FRONT;
    }
}