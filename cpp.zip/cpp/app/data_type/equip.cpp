#include <unordered_map>
#include <string>
#include "equip.h"

// 装备ID到名称的映射表
const std::unordered_map<EquipType, std::string> g_equipIdToNameMap = {{MONKEY_KING_BAR, "金箍棒"},
                                                                       {BOOTS_OF_TRAVEL, "回城卷轴"},
                                                                       {KELENS_DAGGER, "跳刀"},
                                                                       {BLACK_KING_BAR, "黑皇杖"},
                                                                       {GHOST_SCEPTER, "绿杖"},
                                                                       {AGHANIM_SCEPTER, "神之一手"},
                                                                       {KELENS_SHEEP, "羊刀"}};

// 装备ID到价格的映射表
const std::unordered_map<EquipType, int> g_equipIdToPriceMap = {{MONKEY_KING_BAR, 500}, {BOOTS_OF_TRAVEL, 200},
                                                                {KELENS_DAGGER, 200},   {BLACK_KING_BAR, 500},
                                                                {GHOST_SCEPTER, 300},   {AGHANIM_SCEPTER, 300},
                                                                {KELENS_SHEEP, 500}};

// 根据装备ID获取名称的函数
std::string GetEquipName(EquipType equipId)
{
    auto it = g_equipIdToNameMap.find(equipId);
    if (it != g_equipIdToNameMap.end()) {
        return it->second;
    }
    return "未知装备";  // 未找到对应的装备ID
}

int GetEquipPrice(EquipType equipId)
{
    auto it = g_equipIdToPriceMap.find(equipId);
    if (it != g_equipIdToPriceMap.end()) {
        return it->second;
    }
    return 99999;  // 未找到对应的装备ID
}

// 获取符文类型名称的函数
std::string getRuneName(RuneType runeType)
{
    switch (runeType) {
        case GOLD:
            return "金币";
        case DOUBLE_ATTACK:
            return "双倍攻击";
        case RECOVERY:
            return "恢复符";
        default:
            return "未知符文";
    }
}