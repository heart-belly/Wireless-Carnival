#pragma once

#include "base_type.h"
#include "string"
#include "pos.h"

enum TargetType {
    OPP_HERO,
    OPP_SOLDIER,
    OPP_ALL,
    TARGET_SPECIAL,  // 需要特殊处理的技能
    TARGET_ALL
};

// 定义技能配置结构体
struct SkillCfg {
    int castDistance;  // 施法距离
    int castRange;     // 覆盖范围
    TargetType targetType;
};

std::string GetSkillName(SkillId skillId);
SkillCfg* GetSkillCfg(SkillId skillId);
bool IsInSkillRange(Pos src, const Pos& target, SkillId skillId, Pos& skillReleasePos);
bool IsInSkillRange(Pos src, const Pos& target, int castDistance, int castRange, Pos& skillReleasePos);