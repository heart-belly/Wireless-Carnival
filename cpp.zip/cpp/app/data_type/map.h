#pragma once

#include "vector"
#include "pos.h"
#include "base_type.h"

using namespace std;

enum FindPathResult{
    PATH_FOUND,
    PATH_NOT_FOUND,
    ALREADY_AT_DESTINATION
};

class Map {
public:
    int maxX;
    int maxY;
    vector<vector<int> > mapValue_;

    void Print() const;
    FindPathResult GetNextPos(const Pos &src, const vector<Pos> &targetList, Pos &next) const;
    FindPathResult GetNextPos(const Pos &src, const vector<Pos> &targetList, Pos &next, Pos &target) const;
    bool IsWithinMap(const Pos &pos) const;
    void SetValue(const Pos& pos, MapPosType type);
    void SetValueAround(Pos pos, int distance, DistanceType distanceType, MapPosType posType);
    FindPathResult GetNextPos(const Pos& src, const vector<Pos>& targetList, Pos& next, Pos& target, int& pathLength) const;
    static bool IsReachable(MapPosType type);
    bool IsReachable(Pos pos) const;
    bool IsDanger(const Pos& pos);
    MapPosType GetValue(const Pos& pos);
};