#pragma once

#include "json_type.h"
#include "game_start_msg.h"
#include "inquire_msg.h"
#include "map.h"
#include "hero.h"
#include "base_type.h"
#include "unit.h"
#include <vector>
#include <set>

class GameContext {
private:
    int ownPlayerId_;
    GameInitialInfo initialInfo_;
    GameRoundInfo roundInfo_;
    // 游戏初始时候的基础地图信息，在game start msg里面初始化后就不再变化
    Map initialMap_;
    // 根据本轮实时信息，在initialMap_上，标记当前不可达的点
    Map roundMap_;
    // 在roundMap_的基础上，将敌方防御塔，英雄的攻击范围（普通攻击）内的点，设置为不可达
    Map riskMap_;

public:
    Map GetRiskMap() const;

private:
    vector<Hero*> myHeroes_;
    int direction_ = 1;

public:
    int GetDirection() const;
    static GameContext& Instance();

    // 获取当前的实时信息接口
    vector<HeroInfo> GetOppHeroInfo() const;
    const Base* GetMyBase() const;
    const Base* GetOppBase() const;
    vector<TowerDetail> GetOppTowers() const;
    vector<SoldierDetail> GetOppSoldiers() const;
    vector<SoldierDetail> GetMySoldiers() const;
    const Shop& GetShop() const;

    void SetOwnPlayerId(int playerId);
    int GetOwnPlayerId() const;
    const vector<Hero*>& GetMyHeroes() const;
    int GetRound() const;
    void UpdateByStartMsg(const GameInitialInfo& initialInfo);
    void UpdateByInquireMsg(const GameRoundInfo& roundInfo);
    void InitMap(const StaticMap& map);
    // 获取当前轮的实时地图，在初始地图基础上，将所有不可达区域进行标记
    Map GetRoundMap();
    Map GetinitMap();
    void UpdateHero(const vector<HeroInfo>& heroInfoList);
    void CreateHero(const vector<HeroInfo>& heroInfoList);
    void UpdateRoundMap(const GameRoundInfo& info);
    Rune GetRune() const;
    vector<TowerDetail> GetMyTowers() const;
    int CalcAttackDirection();
    Hero* GetTeammate(const Hero& hero);
    vector<DefenseTower> GetOppDefenseTower() const;
    bool IsMySoldierInRange(DefenseTower defenseTower) const;
    bool IsMyHeroInRange(DefenseTower defenseTower) const;
    vector<DefenseTower> GetMyDefenseTower() const;
    void UpdateRiskMap();
    vector<Unit> GetOppUnit() const;
    const vector<Hero*> GetMyAliveHeroes() const;
    vector<HeroInfo> GetOppAliveHeroInfo() const;
    vector<HeroInfo> GetMyAliveHeroInfo() const;
    bool IsOppSoldierInRange(DefenseTower defenseTower) const;
    bool IsOppHeroInRange(DefenseTower defenseTower) const;
    int GetOppSoldierInRangeNumber(DefenseTower defenseTower) const;
};
