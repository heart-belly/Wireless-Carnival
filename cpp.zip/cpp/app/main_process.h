#pragma once

#include <cstdio>
#include "socket_connect.h"
#include "memory"

class MainProcess {
protected:
    unique_ptr<SocketConnect> socketConnect_;

public:
    MainProcess(std::unique_ptr<SocketConnect> socketConnect);
    ~MainProcess(void);

    int Connect(int myId, const string& serverIp, unsigned short serverPort, string name);
    int Run();
    int Disconnect();

private:
    int ProcessMsg();
    int Register(int teamId, string &teamName);
};
