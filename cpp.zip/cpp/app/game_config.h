#ifndef GAME_CONFIG_H
#define GAME_CONFIG_H

#ifndef __cplusplus
#include "stdbool.h"
#endif
#include "base_type.h"

#ifdef __cplusplus
extern "C" {
#endif

#define TEAM_NAME "参与就行了"         // 队名
extern const HeroType g_clientHero1;  // 选择的第一个英雄
extern const HeroType g_clientHero2;  // 选择的第二个英雄

#define PRINT_LEVEL_MASK 0xE // 日志级别控制掩码，默认不打印和固化DEBUG类型的消息
#define EN_COLOR_PRINT        // 默认使能带颜色的日志

// 游戏中的一些可以调节的参数
#define SAFE_DISTANCE_TO_FRONT 2    // 距离敌方前排英雄的安全距离
#define SAFE_DISTANCE_LOW_HP 4      // 血量低时距离敌方英雄的安全距离
#define DISTANCE_TEAMMATE 4         // 平时同伴之间的距离小于该值时，则先靠拢
#define MAX_DISTANCE_TO_BUY 20      // 距离过远就不去买装备
#define MAX_DISTANCE_ATTACK 5       // 主动发起攻击的距离

extern int g_breakRound;  // 从启动参数中解析
extern int g_maxRound;
extern bool g_isStepTo;   // 从启动参数中解析
extern bool isCanGo;
extern bool isUseOpenStrategy;
extern bool isGrass;
#ifdef __cplusplus
}
#endif

#endif /* GAME_CONFIG_H */