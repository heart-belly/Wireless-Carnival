#include "game_config.h"

int g_breakRound = -1;
int g_maxRound = -1;
bool g_isStepTo = false;


bool isCanGo = true;
bool isUseOpenStrategy = true;
bool isGrass = false;
const HeroType g_clientHero1 = CRYSTAL_MAIDEN;
const HeroType g_clientHero2 = SNIPER;