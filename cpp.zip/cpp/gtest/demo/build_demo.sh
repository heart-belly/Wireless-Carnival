g++ -std=c++11 alarm_test.cpp -I./include -lpthread ./lib/libgtest.a ./lib/libgmock.a -o  alarm_test
