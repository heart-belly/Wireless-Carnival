#include <stdio.h>
#include <stdlib.h>
#include "gmock/gmock.h"


TEST(COutputPopLimitStrategyTest,PositiveNos){
EXPECT_EQ(true,true);
}

int main(int argc,char *argv[]){
::testing::InitGoogleTest(&argc,argv);

return RUN_ALL_TESTS();
}



