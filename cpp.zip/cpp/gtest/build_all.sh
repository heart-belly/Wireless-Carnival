rm -rf ./googletest/CMakeFiles
rm -rf ./googlemock/CMakeFiles
rm -rf ./lib
cmake ./
make
