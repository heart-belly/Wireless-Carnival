#!/bin/bash

rm -rf build
mkdir build
cd build
cmake ..

# 编译源文件
make main

# 检查编译是否成功
if [ $? -ne 0 ]; then
    echo "Compilation failed"
    exit 1
fi

# 压缩文件
mv app/main ./main
zip BattleCode.zip main

# 检查压缩是否成功
if [ $? -ne 0 ]; then
    echo "Compression failed"
    exit 1
fi

# 复制 ZIP 文件到 /home 目录
cp BattleCode.zip /home

# 检查复制是否成功
if [ $? -ne 0 ]; then
    echo "Copy failed"
    exit 1
fi

echo "Demo file compiled, compressed, and copied to /home successfully"

