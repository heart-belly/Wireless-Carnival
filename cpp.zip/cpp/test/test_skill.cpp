#include "gtest/gtest.h"
#include "pos.h"

using namespace std;

class SkillTest : public ::testing::Test {
public:
    virtual void SetUp() {}
    virtual void TearDown() {}
    static void SetUpTestCase() {}
    static void TearDownTestCase()
    {
    }
};

bool IsInSkillRange2(const Pos src, const Pos &target, int skillRange, int skillCoverage, Pos &skillReleasePos)
{
    for (int dx = -skillRange; dx <= skillRange; ++dx) {
        for (int dy = -skillRange; dy <= skillRange; ++dy) {
            const Pos skillReleasePoint = {src.x_ + dx, src.y_ + dy};
            // 检查技能释放点是否在地图范围内
            if (skillReleasePoint.IsNeighbor(target, skillCoverage, CHEBYSHEV)) {
                skillReleasePos = skillReleasePoint;
                return true;
            }
        }
    }
    return false;
}

TEST_F(SkillTest, IsInSkillRange)
{
    Pos src(25, 15);
    Pos target(31, 9);
    Pos release;
    bool ret = IsInSkillRange2(src, target, 6, 0, release);
    EXPECT_EQ(ret, true);
    EXPECT_EQ(release, target);
    ret = IsInSkillRange2(src, target, 5, 0, release);
    EXPECT_EQ(ret, false);
    ret = IsInSkillRange2(src, target, 7, 0, release);
    EXPECT_EQ(ret, true);
    EXPECT_EQ(release, target);
}
