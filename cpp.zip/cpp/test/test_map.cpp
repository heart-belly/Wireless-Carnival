#include "gtest/gtest.h"
#include "pos.h"
#include "bfs.h"
#include "map.h"

using namespace std;

class MapTest : public ::testing::Test {
public:
    virtual void SetUp() {}
    virtual void TearDown() {}
    static void SetUpTestCase() {}
    static void TearDownTestCase()
    {
    }
};

void DoBfsTest(const vector<std::vector<int> > &grid, const Pos &start, const Pos &end)
{
    // 找到完整路径
    std::vector<Pos> path = BFS_FindPath(grid, start, end);
    if (!path.empty()) {
        std::cout << "Full path found: \n";
        for (const auto& point : path) {
            std::cout << point << ", "; // 按照 (x, y) 输出
        }
        std::cout << std::endl;
    } else {
        std::cout << "No full path found." << std::endl;
    }

    // 找到下一步移动
    Pos next;
    bool found = BFS_GetNextMove(grid, start, end, next);
    if (found) {
        std::cout << "Next move: (" << next << ")" << std::endl; // 按照 (x, y) 输出
    } else {
        std::cout << "No next move available." << std::endl;
    }
}

TEST_F(MapTest, findNextStep_1)
{
    // 示例地图改为长方形网格
    std::vector<std::vector<int>> grid = {
        {0, 0, 1, 0},
        {0, 0, 0, 0},
        {0, 0, 1, 1},
        {0, 0, 1, 0},
        {0, 0, 0, 0}
    };

    Pos start = {0, 0}; // 初始点 (x, y)，这里是 (0, 0)
    Pos end = {3, 4}; // 终点 (x, y)，这里是一个长方形，终点的行数为 4，列数为 3

    DoBfsTest(grid, start, end);
}

TEST_F(MapTest, findNextStep_2)
{
    // 示例地图改为长方形网格
    std::vector<std::vector<int>> grid = {
        {0, 0, 1, 0},
        {0, 0, 0, 0},
        {0, 0, 1, 0},
        {0, 0, 1, 0},
        {0, 0, 1, 0}
    };

    Pos start = {0, 0}; // 初始点 (x, y)，这里是 (0, 0)
    Pos end = {3, 4}; // 终点 (x, y)，这里是一个长方形，终点的行数为 4，列数为 3

    DoBfsTest(grid, start, end);
}

TEST_F(MapTest, findNextStep_3)
{
    // 示例地图改为长方形网格
    std::vector<std::vector<int>> grid = {
        {0, 1, 0, 0},
        {0, 0, 1, 0},
        {0, 0, 1, 0},
        {0, 0, 1, 0},
        {0, 0, 1, 0}
    };

    Pos start = {0, 0}; // 初始点 (x, y)，这里是 (0, 0)
    Pos end = {3, 4}; // 终点 (x, y)，这里是一个长方形，终点的行数为 4，列数为 3

    DoBfsTest(grid, start, end);
}

TEST_F(MapTest, SetValue_CHEBYSHEV)
{
    Map map;
    map.mapValue_ = {
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0}
    };
    map.maxX = 7;
    map.maxY = 9;
    map.SetValueAround(Pos(3, 4), 2, CHEBYSHEV, DANGER);
    map.Print();
}

TEST_F(MapTest, SetValue_MANHATTAN_1)
{
    Map map;
    map.mapValue_ = {
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0}
    };
    map.maxX = 7;
    map.maxY = 9;
    map.SetValueAround(Pos(3, 4), 2, MANHATTAN, DANGER);
    map.Print();
}

TEST_F(MapTest, SetValue_MANHATTAN_2)
{
    Map map;
    map.mapValue_ = {
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0}
    };
    map.maxX = 7;
    map.maxY = 9;
    map.SetValueAround(Pos(1, 1), 2, MANHATTAN, DANGER);
    map.Print();
}