#include "gtest/gtest.h"
#include "action_msg.h"
#include "client_ban_msg.h"
#include "client_pick_msg.h"
#include "register_msg.h"
#include "ready_msg.h"

using namespace std;

class ClientMsgTest : public ::testing::Test {
public:
    virtual void SetUp() {}
    virtual void TearDown() {}
    static void SetUpTestCase() {}
    static void TearDownTestCase()
    {
    }
};

TEST_F(ClientMsgTest, RegisterMsg_send)
{
    RegisterMsg msg;
    msg.playerId = 9527;
    msg.version = "1.0";
    msg.name = "9527无敌";

    string jsonStr;
    msg.ToJsonStr(jsonStr);
    cout << jsonStr << endl;
}

TEST_F(ClientMsgTest, ReadyMsg_send)
{
    ReadyMsg msg;
    msg.playerId = 9527;

    string jsonStr;
    msg.ToJsonStr(jsonStr);
    cout << jsonStr << endl;
}

TEST_F(ClientMsgTest, ActionMsg_send)
{
    ActionMsg msg;
    msg.playerId = 9527;
    msg.round = 27;
    HeroAction heroAction;
    heroAction.id = 1002;
    heroAction.action.useEquipId = (EquipType)1;
    heroAction.action.type = MOVE;
    heroAction.action.skillId = 1010;
    heroAction.action.targetPos.x_ = 4;
    heroAction.action.targetPos.y_ = 19;
    msg.heroActionList.push_back(heroAction);

    string jsonStr;
    msg.ToJsonStr(jsonStr);
    cout << jsonStr << endl;
}

TEST_F(ClientMsgTest, ClientBanMsg_send)
{
    ClientBanMsg msg;
    msg.playerId = 9527;
    msg.hero = 1688;

    string jsonStr;
    msg.ToJsonStr(jsonStr);
    cout << jsonStr << endl;
}

TEST_F(ClientMsgTest, ClientPickMsg_send)
{
    ClientPickMsg msg;
    msg.playerId = 9527;
    msg.heroes.push_back(1);
    msg.heroes.push_back(2);

    string jsonStr;
    msg.ToJsonStr(jsonStr);
    cout << jsonStr << endl;
}